"""BGEN Picker - A powerful animation picker tool for Maya

Part of the BGEN collection.
"""

__version__ = '3.0.2'
__author__ = 'MUNORR - BGEN'

# Make main functions available at the package level
from .main import open

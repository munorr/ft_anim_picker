"""Controller Manager Dialog for configuring picker button controller mode.

Allows setting Blender data path, value range, precision, and label
visibility for controller-mode picker buttons.
"""

import bpy
from PySide6 import QtWidgets, QtCore, QtGui

from . import utils as UT
from . import custom_button as CB
from .custom_segment_control import TextSegmentControl
from . import custom_button as CB

# -- Colour tokens (matches LaunchDialog / settings_page) -------------------
_BG         = "#1d1d1d"
_BORDER     = "rgba(255,255,255,0.06)"
_TEXT_MAIN  = "#e0e0e0"
_TEXT_SUB   = "#808080"
_TEXT_MUTED = "#666666"
_ACCENT     = "#1D65CA"
_SURFACE    = "rgba(255,255,255,{a})"
_CARD_BG    = "rgba(50,50,50,0.2)"
_INPUT_BG   = "rgba(50, 50, 50, 0.8)"
_INPUT_BORDER = "#3a3a3a"


def _make_btn(text, bg_tpl, text_color, *, border=False, height=32):
    """Create a styled button matching the codebase pattern."""
    btn = QtWidgets.QPushButton(text)
    btn.setFixedHeight(height)
    btn.setCursor(QtCore.Qt.PointingHandCursor)
    border_css = (
        f"border: 1px solid {_SURFACE.format(a='0.10')};"
        if border else "border: none;"
    )
    btn.setStyleSheet(f"""
        QPushButton {{
            background: {bg_tpl.format(a='0.55')};
            color: {text_color};
            {border_css}
            border-radius: 6px;
            font-size: 12px;
            font-weight: 500;
            padding: 0 14px;
        }}
        QPushButton:hover {{
            background: {bg_tpl.format(a='0.80')};
        }}
        QPushButton:pressed {{
            background: {bg_tpl.format(a='0.95')};
        }}
    """)
    return btn


class ControllerManagerDialog(QtWidgets.QWidget):
    """Popup dialog for configuring a controller-mode picker button."""

    def __init__(self, button, parent=None):
        if parent is None:
            from . import blender_main as MAIN
            manager = MAIN.PickerWindowManager.get_instance()
            parent = manager._picker_widgets[0] if manager._picker_widgets else None
        super().__init__(parent)
        self.setWindowFlags(
            QtCore.Qt.Window
            | QtCore.Qt.FramelessWindowHint
            | QtCore.Qt.WindowStaysOnTopHint
        )
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground)
        self.button = button

        self.setFixedWidth(300)

        # Register with visibility manager
        self.parent_picker = parent
        if self.parent_picker:
            from . import blender_main
            visibility_manager = blender_main.PickerVisibilityManager.get_instance()
            visibility_manager.register_child_widget(self.parent_picker, self)

        # Dragging support
        self._drag_pos = None

        self._build_ui()
        self._populate_from_button()
        self._position_center()
        self.show()

    # ── UI Construction ───────────────────────────────────────────────────

    def _build_ui(self):
        outer = QtWidgets.QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        # Main styled card frame
        self.frame = QtWidgets.QFrame()
        self.frame.setStyleSheet(f"""
            QFrame {{
                background-color: {_BG};
                border-radius: 8px;
                border: 1px solid {_BORDER};
            }}
        """)
        root = QtWidgets.QVBoxLayout(self.frame)
        root.setContentsMargins(12, 12, 12, 12)
        root.setSpacing(0)

        # ── Title row ──
        title_row = QtWidgets.QHBoxLayout()
        title_row.setContentsMargins(0, 0, 0, 0)
        title = QtWidgets.QLabel("Controller Manager")
        title.setStyleSheet(
            f"color: {_TEXT_MAIN}; font-size: 14px; font-weight: 600; "
            "background: transparent; border: none;"
        )
        title_row.addWidget(title)
        title_row.addStretch()

        self.close_button = CB.CustomButton(icon=UT.get_icon('close_01.png',size=16,opacity=1), height=26, width=26, radius=26/2,color='#db2525',tooltip='Close')
        self.close_button.clicked.connect(self._close)
        title_row.addWidget(self.close_button)
        root.addLayout(title_row)
        root.addSpacing(14)

        # ── Data Path card ──
        dp_card = self._card()
        dp_lay = QtWidgets.QVBoxLayout(dp_card)
        dp_lay.setContentsMargins(12, 10, 12, 12)
        dp_lay.setSpacing(8)

        # Path type row
        pt_row = QtWidgets.QHBoxLayout()
        pt_label = self._section_label("Path Type")
        pt_row.addWidget(pt_label)
        pt_row.addStretch()

        self.path_type_segment = TextSegmentControl(
            ["Absolute", "Relative"],
            height=24,
            font_size=11,
            radius=6,
            frame_radius=6,
            use_frame=True,
            frame_bg="rgba(255, 255, 255, 0.06)",
            selected_color="#1D65CA",
            expand=False,
        )
        pt_row.addWidget(self.path_type_segment)
        dp_lay.addLayout(pt_row)

        # Slider theme row
        st_row = QtWidgets.QHBoxLayout()
        st_label = self._section_label("Slider Theme")
        st_row.addWidget(st_label)
        st_row.addStretch()

        self.slider_theme_segment = TextSegmentControl(
            ["Bar", "Circle"],
            height=24,
            font_size=11,
            radius=6,
            frame_radius=6,
            use_frame=True,
            frame_bg="rgba(255, 255, 255, 0.06)",
            selected_color="#1D65CA",
            expand=False,
        )
        st_row.addWidget(self.slider_theme_segment)
        dp_lay.addLayout(st_row)

        # Path input
        self.data_path_edit = QtWidgets.QLineEdit()
        self.data_path_edit.setPlaceholderText(
            'pose.bones["Bone"].location[0]'
        )
        self.data_path_edit.setStyleSheet(self._input_ss())
        self.data_path_edit.setFixedHeight(30)
        dp_lay.addWidget(self.data_path_edit)

        # Test row
        test_row = QtWidgets.QHBoxLayout()
        self.test_btn = CB.CustomButton("Test Path", height=28, color="#1D65CA")
        self.test_btn.clicked.connect(self._test_path)
        test_row.addWidget(self.test_btn)
        self.test_result_label = QtWidgets.QLabel("")
        self.test_result_label.setStyleSheet(
            f"color: {_TEXT_MUTED}; background: transparent; border: none; font-size: 11px;"
        )
        test_row.addWidget(self.test_result_label, 1)
        dp_lay.addLayout(test_row)

        root.addWidget(dp_card)
        root.addSpacing(8)

        # ── Range card ──
        range_card = self._card()
        range_lay = QtWidgets.QVBoxLayout(range_card)
        range_lay.setContentsMargins(12, 10, 12, 12)
        range_lay.setSpacing(8)

        range_header = self._section_label("Range & Precision")
        range_lay.addWidget(range_header)

        # Min / Max row
        mm_row = QtWidgets.QHBoxLayout()
        mm_row.setSpacing(10)
        for label_text, attr_name, default in [("Min", "min_edit", "0.0"), ("Max", "max_edit", "1.0")]:
            lbl = QtWidgets.QLabel(label_text)
            lbl.setStyleSheet(
                f"color: {_TEXT_SUB}; background: transparent; border: none; font-size: 11px;"
            )
            edit = QtWidgets.QLineEdit(default)
            edit.setFixedHeight(24)
            edit.setAlignment(QtCore.Qt.AlignCenter)
            edit.setStyleSheet(self._input_ss())
            setattr(self, attr_name, edit)
            mm_row.addWidget(lbl)
            mm_row.addWidget(edit, 1)
        range_lay.addLayout(mm_row)

        # Precision / Default / Step row
        pds_row = QtWidgets.QHBoxLayout()
        pds_row.setSpacing(10)
        for label_text, attr_name, default in [("Precision", "precision_edit", "2"), ("Default", "default_edit", "0.0"), ("Step", "step_edit", "0.01")]:
            lbl = QtWidgets.QLabel(label_text)
            lbl.setStyleSheet(
                f"color: {_TEXT_SUB}; background: transparent; border: none; font-size: 11px;"
            )
            edit = QtWidgets.QLineEdit(default)
            edit.setFixedHeight(24)
            edit.setAlignment(QtCore.Qt.AlignCenter)
            edit.setStyleSheet(self._input_ss())
            setattr(self, attr_name, edit)
            pds_row.addWidget(lbl)
            pds_row.addWidget(edit, 1)
        range_lay.addLayout(pds_row)

        root.addWidget(range_card)
        root.addSpacing(14)

        # ── Apply button ──
        self.apply_btn = _make_btn("Apply", _ACCENT, _TEXT_MAIN)
        self.apply_btn.clicked.connect(self._apply)
        root.addWidget(self.apply_btn)

        outer.addWidget(self.frame)

    # ── Population & Apply ────────────────────────────────────────────────

    def _populate_from_button(self):
        cd = self.button.controller_data
        if not cd:
            self.path_type_segment.set_selected_index(0)
            return

        if cd.get('path_type', 'absolute') == 'relative':
            self.path_type_segment.set_selected_index(1)
        else:
            self.path_type_segment.set_selected_index(0)

        if cd.get('slider_theme', 'bar') == 'circle':
            self.slider_theme_segment.set_selected_index(1)
        else:
            self.slider_theme_segment.set_selected_index(0)

        self.data_path_edit.setText(cd.get('data_path', ''))

        self.min_edit.setText(str(cd.get('min_value', 0.0)))
        self.max_edit.setText(str(cd.get('max_value', 1.0)))
        self.precision_edit.setText(str(cd.get('precision', 2)))
        self.default_edit.setText(str(cd.get('default_value', 0.0)))
        self.step_edit.setText(str(cd.get('step', 0.01)))

    def _apply(self):
        cd = {
            'field_type': 'slider',
            'slider_theme': 'circle' if self.slider_theme_segment.get_selected_index() == 1 else 'bar',
            'data_path': self.data_path_edit.text().strip(),
            'path_type': 'relative' if self.path_type_segment.get_selected_index() == 1 else 'absolute',
            'min_value': self._safe_float(self.min_edit.text(), 0.0),
            'max_value': self._safe_float(self.max_edit.text(), 1.0),
            'precision': max(0, min(6, int(self._safe_float(self.precision_edit.text(), 2)))),
            'default_value': self._safe_float(self.default_edit.text(), 0.0),
            'step': self._safe_float(self.step_edit.text(), 0.01),
        }

        self.button.controller_data = cd

        # Restart sync with new path
        self.button._stop_controller_sync()
        val = self.button._read_controller_value()
        if val is not None:
            self.button._controller_value = val
        else:
            self.button._controller_value = cd['default_value']
        self.button._start_controller_sync()

        # Invalidate pixmap and save
        self.button.controller_pixmap = None
        canvas = self.button.parent()
        if canvas:
            canvas.update()
        self.button.changed.emit(self.button)

        # Flush to database
        main_window = self.button.window()
        from . import blender_ui as UI
        if isinstance(main_window, UI.BlenderAnimPickerWindow):
            if hasattr(main_window, 'pending_button_updates'):
                main_window.pending_button_updates.add(self.button.unique_id)
            if hasattr(main_window, '_flush_pending_updates'):
                main_window._flush_pending_updates()

        self._close()

    def _test_path(self):
        """Test the data path by reading the current value."""
        old_cd = self.button.controller_data
        test_cd = dict(old_cd) if old_cd else {}
        test_cd['data_path'] = self.data_path_edit.text().strip()
        test_cd['path_type'] = 'relative' if self.path_type_segment.get_selected_index() == 1 else 'absolute'
        self.button.controller_data = test_cd
        self.button._controller_last_error = ''

        resolved = self.button._resolve_controller_data_path()
        val = self.button._read_controller_value()
        self.button.controller_data = old_cd  # Restore

        if val is not None:
            precision = max(0, min(6, int(self._safe_float(self.precision_edit.text(), 2))))
            self.test_result_label.setText(f"= {val:.{precision}f}")
            self.test_result_label.setToolTip(f"Resolved: {resolved}")
            self.test_result_label.setStyleSheet(
                "color: #4caf50; background: transparent; border: none; font-size: 11px;"
            )
        else:
            error = getattr(self.button, '_controller_last_error', '')
            tip = f"Resolved: {resolved}\nError: {error}" if resolved else "Could not resolve path (no armature found)"
            self.test_result_label.setText("Invalid path")
            self.test_result_label.setToolTip(tip)
            self.test_result_label.setStyleSheet(
                "color: #f44336; background: transparent; border: none; font-size: 11px;"
            )

    # ── Helpers ───────────────────────────────────────────────────────────

    def _close(self):
        if self.parent_picker:
            from . import blender_main
            visibility_manager = blender_main.PickerVisibilityManager.get_instance()
            visibility_manager.unregister_child_widget(self.parent_picker, self)
        self.close()
        self.deleteLater()

    def exec(self):
        """Show and keep visible (non-blocking, frameless window)."""
        self.show()
        self.raise_()
        self.activateWindow()

    def _position_center(self):
        """Center the dialog within the parent picker window."""
        if self.parent_picker:
            pw = self.parent_picker
            geo = pw.geometry()
            self.adjustSize()
            dw = self.width()
            dh = self.height()
            cx = geo.x() + (geo.width() - dw) // 2
            cy = geo.y() + (geo.height() - dh) // 2
            self.move(cx, cy)

    @staticmethod
    def _safe_float(text, default=0.0):
        try:
            return float(text)
        except (ValueError, TypeError):
            return default

    # ── Dragging ──────────────────────────────────────────────────────────

    def mousePressEvent(self, event):
        if event.button() == QtCore.Qt.LeftButton:
            self._drag_pos = event.globalPos() - self.frameGeometry().topLeft()
            event.accept()

    def mouseMoveEvent(self, event):
        if self._drag_pos is not None and event.buttons() & QtCore.Qt.LeftButton:
            self.move(event.globalPos() - self._drag_pos)
            event.accept()

    def mouseReleaseEvent(self, event):
        self._drag_pos = None

    # ── Widget factories ──────────────────────────────────────────────────

    @staticmethod
    def _card():
        """Create a styled card QFrame matching codebase pattern."""
        card = QtWidgets.QFrame()
        card.setStyleSheet(f"""
            QFrame {{
                background: {_CARD_BG};
                border: 1px solid {_BORDER};
                border-radius: 8px;
            }}
        """)
        return card

    @staticmethod
    def _section_label(text):
        lbl = QtWidgets.QLabel(text)
        lbl.setStyleSheet(
            f"color: {_TEXT_MAIN}; font-size: 11px; font-weight: 600; "
            "background: transparent; border: none;"
        )
        return lbl

    @staticmethod
    def _input_ss():
        return f"""
            QLineEdit {{
                background: {_INPUT_BG};
                color: {_TEXT_MAIN};
                border: 1px solid {_INPUT_BORDER};
                border-radius: 6px;
                padding: 3px 8px;
                font-size: 11px;
            }}
            QLineEdit:focus {{
                border: 1px solid rgba(29,101,202,0.6);
            }}
            QLineEdit::placeholder {{
                color: {_TEXT_MUTED};
            }}
        """

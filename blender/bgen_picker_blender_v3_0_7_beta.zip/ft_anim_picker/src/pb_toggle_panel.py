"""Toggle Panel for the Script Manager.

Declarative UI for building 2-state toggle buttons. The whole panel lives
inside a single scroll area (Save Code button stays outside in the
ScriptManagerWidget). Inner layout (top → bottom):

1. State 1 / State 2 segment control
2. Button Appearance cards + "Add Button Appearance Control"
3. Per-state code editor

``target_buttons`` on each appearance is shared across states; per-state
values (color, label, opacity, selectable) diverge. Switching the state
segment serializes the visible state's card values into ``_appearance_data``
then repopulates the cards from the other state.
"""

from PySide6 import QtWidgets, QtCore, QtGui

from . import custom_segment_control as CSC
from . import pb_button_appearance_card as PBAC


_SCROLL_STYLE = """
    QScrollArea { background: transparent; border: none; }
    QScrollBar:vertical { border: none; background: transparent; width: 8px; padding-top: 6px; padding-bottom: 6px; margin: 2px; }
    QScrollBar::handle:vertical { background: rgba(100,100,100,0.4); border-radius: 3px; min-height: 20px; }
    QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0px; }
    QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical { background: transparent; }
"""


class TogglePanel(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._picker_button = None
        self._active_state = 0
        self._current_state_runtime = 0
        self._cards = []
        self._appearance_data = []
        self._state_code_cache = ['', '']
        self._build_ui()
        self.set_toggle_data(None)

    # ── UI ──────────────────────────────────────────────────────────────
    def _build_ui(self):
        # Outer layout holds the pinned state segment + scroll area below.
        outer = QtWidgets.QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(8)

        self.setStyleSheet("QWidget { background: 1d1d1d; border: none;}")

        # State selector — kept *outside* the scroll area so it stays pinned
        # at the top while the appearance list scrolls beneath it.
        self.state_segment = CSC.TextSegmentControl(
            ["State 1", "State 2"],
            height=28, font_size=11, radius=6,
            frame_radius=6, use_frame=True,
            frame_bg="rgba(255, 255, 255, 0.06)",
            selected_color="#1D65CA",
            expand=True,
        )
        self.state_segment.segment_changed.connect(self._on_state_changed)
        outer.addWidget(self.state_segment)

        self.scroll_area = QtWidgets.QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.scroll_area.setStyleSheet(_SCROLL_STYLE)
        self.scroll_area.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        self.scroll_area.viewport().setAutoFillBackground(False)
        self.scroll_area.setAttribute(QtCore.Qt.WA_TranslucentBackground, False)
        outer.addWidget(self.scroll_area)

        content = QtWidgets.QWidget()
        root = QtWidgets.QVBoxLayout(content)
        root.setContentsMargins(6, 6, 6, 6)
        root.setSpacing(8)
        self.scroll_area.setWidget(content)

        # Appearance list container — borderless, no tint
        self.list_frame = QtWidgets.QFrame()
        self.list_frame.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.list_frame.setStyleSheet("QFrame { background: transparent; border: none; }")
        list_frame_layout = QtWidgets.QVBoxLayout(self.list_frame)
        list_frame_layout.setContentsMargins(6, 6, 6, 6)
        list_frame_layout.setSpacing(8)

        self._list_layout = QtWidgets.QVBoxLayout()
        self._list_layout.setContentsMargins(0, 0, 0, 0)
        self._list_layout.setSpacing(6)
        list_frame_layout.addLayout(self._list_layout)

        self.add_appearance_btn = QtWidgets.QPushButton("+  Add Button Appearance Control")
        self.add_appearance_btn.setFixedHeight(28)
        self.add_appearance_btn.setCursor(QtCore.Qt.PointingHandCursor)
        self.add_appearance_btn.setStyleSheet("""
            QPushButton {
                background: rgba(255, 255, 255, 0.04);
                color: #cccccc; border: 1px dashed rgba(255,255,255,0.10);
                border-radius: 6px; font-size: 11px;
            }
            QPushButton:hover { background: rgba(255, 255, 255, 0.08); color: #ffffff; }
        """)
        self.add_appearance_btn.clicked.connect(self._on_add_appearance)
        list_frame_layout.addWidget(self.add_appearance_btn)

        root.addWidget(self.list_frame)

        # Per-state code editor — wrapped in a rounded container matching the
        # main Script Manager editor (transparent editor sits on a #252525
        # radius-8 frame so the scrollbars align with the corners).
        from . import pb_script_manager as PSM
        self.editor_container = QtWidgets.QFrame()
        self.editor_container.setStyleSheet(PSM.CODE_EDITOR_CONTAINER_STYLE)
        ec_lay = QtWidgets.QVBoxLayout(self.editor_container)
        ec_lay.setContentsMargins(0, 0, 0, 0)
        ec_lay.setSpacing(0)

        self.code_editor = PSM.CodeEditor()
        self.code_editor.setStyleSheet(PSM.CODE_EDITOR_STYLE)
        self.code_editor.setMinimumHeight(120)
        self.code_editor.document().setDocumentMargin(5)
        font = self.code_editor.font()
        fm = QtGui.QFontMetrics(font)
        self.code_editor.setTabStopDistance(fm.horizontalAdvance(' ') * 4)
        self._highlighter = PSM.ScriptSyntaxHighlighter(self.code_editor.document())
        self.code_editor.textChanged.connect(self._on_code_changed)
        ec_lay.addWidget(self.code_editor)
        root.addWidget(self.editor_container)

        root.addStretch(0)

    # ── Public API ──────────────────────────────────────────────────────
    def set_toggle_data(self, toggle_data, picker_button=None):
        self._picker_button = picker_button
        data = dict(toggle_data) if toggle_data else {}
        self._appearance_data = [dict(a) for a in (data.get('appearances') or [])]
        for ap in self._appearance_data:
            ap.setdefault('id', f"ap_{id(ap)}")
            ap.setdefault('name', 'Button Appearance')
            ap.setdefault('target_buttons', [])
            ap.setdefault('state_1', dict(PBAC.DEFAULT_STATE))
            ap.setdefault('state_2', dict(PBAC.DEFAULT_STATE))
        self._state_code_cache = [
            data.get('state_1_code', '') or '',
            data.get('state_2_code', '') or '',
        ]
        self._current_state_runtime = int(data.get('current_state', 0) or 0)
        self._active_state = 0
        self.state_segment.blockSignals(True)
        self.state_segment.set_selected_index(0)
        self.state_segment.blockSignals(False)
        self._rebuild_cards()
        self._load_editor_for_active_state()

    def get_toggle_data(self):
        self._sync_cards_into_data()
        self._sync_editor_into_cache()
        return {
            'current_state': self._current_state_runtime,
            'appearances': [dict(a) for a in self._appearance_data],
            'state_1_code': self._state_code_cache[0],
            'state_2_code': self._state_code_cache[1],
        }

    # ── State switching ────────────────────────────────────────────────
    def _on_state_changed(self, index):
        if index == self._active_state:
            return
        self._sync_cards_into_data()
        self._sync_editor_into_cache()
        self._active_state = index
        self._populate_cards_from_state()
        self._load_editor_for_active_state()

    # ── Cards ──────────────────────────────────────────────────────────
    def _rebuild_cards(self):
        for card in self._cards:
            card.setParent(None)
            card.deleteLater()
        self._cards = []
        for ap in self._appearance_data:
            card = self._create_card_widget(ap)
            self._cards.append(card)
            self._list_layout.addWidget(card)
        self._populate_cards_from_state()

    def _create_card_widget(self, ap):
        card = PBAC.ButtonAppearanceCard(name=ap.get('name', 'Button Appearance'))
        card.changed.connect(self._on_card_changed)
        card.name_changed.connect(lambda _n, c=card: self._on_card_renamed(c))
        card.delete_requested.connect(self._on_card_delete)
        card.duplicate_requested.connect(self._on_card_duplicate)
        card.move_up_requested.connect(lambda c: self._move_card(c, -1))
        card.move_down_requested.connect(lambda c: self._move_card(c, +1))
        return card

    def _move_card(self, card, offset):
        """Move a card up (offset=-1) or down (offset=+1) in the list."""
        if card not in self._cards:
            return
        self._sync_cards_into_data()
        i = self._cards.index(card)
        j = i + offset
        if not (0 <= j < len(self._cards)):
            return
        # Swap in both parallel lists
        self._cards[i], self._cards[j] = self._cards[j], self._cards[i]
        self._appearance_data[i], self._appearance_data[j] = self._appearance_data[j], self._appearance_data[i]
        # Reflect in the layout — remove then insert at the new index
        self._list_layout.removeWidget(card)
        self._list_layout.insertWidget(j, card)

    def _populate_cards_from_state(self):
        key = 'state_1' if self._active_state == 0 else 'state_2'
        for card, ap in zip(self._cards, self._appearance_data):
            card.set_state_values(ap.get(key, dict(PBAC.DEFAULT_STATE)))
            card.set_target_buttons(ap.get('target_buttons', []))
            card.set_name(ap.get('name', 'Button Appearance'))

    def _sync_cards_into_data(self):
        key = 'state_1' if self._active_state == 0 else 'state_2'
        for card, ap in zip(self._cards, self._appearance_data):
            ap[key] = card.get_state_values()
            ap['target_buttons'] = card.get_target_buttons()
            ap['name'] = card.get_name()

    def _on_card_changed(self):
        self._sync_cards_into_data()

    def _on_card_renamed(self, _card):
        self._sync_cards_into_data()

    def _on_card_duplicate(self, card):
        if card not in self._cards:
            return
        # Make sure the source's current on-screen edits are captured first
        self._sync_cards_into_data()
        i = self._cards.index(card)
        if not (0 <= i < len(self._appearance_data)):
            return
        import copy
        src = self._appearance_data[i]
        clone = copy.deepcopy(src)
        clone['id'] = f"ap_{id(clone)}"
        clone['name'] = f"{src.get('name', 'Button Appearance')} (copy)"
        self._appearance_data.insert(i + 1, clone)
        new_card = self._create_card_widget(clone)
        self._cards.insert(i + 1, new_card)
        # Re-insert all cards at the right positions to preserve order
        self._list_layout.insertWidget(i + 1, new_card)
        key = 'state_1' if self._active_state == 0 else 'state_2'
        new_card.set_state_values(clone.get(key, dict(PBAC.DEFAULT_STATE)))
        new_card.set_target_buttons(clone.get('target_buttons', []))
        new_card.set_name(clone['name'])

    def _on_card_delete(self, card):
        if card not in self._cards:
            return
        i = self._cards.index(card)
        self._cards.pop(i)
        if 0 <= i < len(self._appearance_data):
            self._appearance_data.pop(i)
        card.setParent(None)
        card.deleteLater()

    def _next_default_name(self):
        """Find the next unused default-style name so deleting/renaming
        doesn't cause a number collision."""
        used = {a.get('name', '') for a in self._appearance_data}
        n = 1
        while True:
            candidate = f"Button Appearance {n:02d}"
            if candidate not in used:
                return candidate, n
            n += 1

    def _on_add_appearance(self):
        name, n = self._next_default_name()
        # Pre-populate shape fields with the source button's current values so
        # new appearance instances start from "as-is" rather than generic
        # defaults — easier to dial in deltas from there.
        base_state = dict(PBAC.DEFAULT_STATE)
        if self._picker_button is not None:
            try:
                base_state['width'] = int(getattr(self._picker_button, 'width', base_state['width']))
                base_state['height'] = int(getattr(self._picker_button, 'height', base_state['height']))
                radius_attr = getattr(self._picker_button, 'radius', None)
                if isinstance(radius_attr, (list, tuple)) and radius_attr:
                    base_state['radius'] = int(radius_attr[0])
                elif radius_attr is not None:
                    base_state['radius'] = int(radius_attr)
                base_state['rotation'] = int(getattr(self._picker_button, 'rotation', base_state['rotation']))
            except Exception:
                pass
        ap = {
            'id': f"ap_{n}_{len(self._appearance_data)}",
            'name': name,
            'target_buttons': [],
            'state_1': dict(base_state),
            'state_2': dict(base_state),
        }
        self._appearance_data.append(ap)
        card = self._create_card_widget(ap)
        self._cards.append(card)
        self._list_layout.addWidget(card)
        key = 'state_1' if self._active_state == 0 else 'state_2'
        card.set_state_values(ap[key])
        card.set_target_buttons(ap['target_buttons'])

    # ── Code editor ────────────────────────────────────────────────────
    def _load_editor_for_active_state(self):
        self.code_editor.blockSignals(True)
        self.code_editor.setPlainText(self._state_code_cache[self._active_state])
        self.code_editor.blockSignals(False)

    def _sync_editor_into_cache(self):
        self._state_code_cache[self._active_state] = self.code_editor.toPlainText()

    def _on_code_changed(self):
        self._sync_editor_into_cache()

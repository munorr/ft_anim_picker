"""
Settings Page — Sidebar navigation with Account, Preferences, Updates, More Info sections.
"""

import os
import sys
import json
import webbrowser
import urllib.request
from pathlib import Path

from PySide6 import QtCore, QtWidgets, QtGui
from PySide6.QtCore import Qt, Signal, QTimer, QRectF
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QLineEdit, QFrame, QStackedWidget, QScrollArea, QButtonGroup,
    QComboBox, QProgressBar, QSizePolicy,
)
from PySide6.QtGui import QPainter, QColor, QIcon

from . import utils as UT
from .config.settings import (
    GITHUB_URL, GITHUB_ISSUES_URL, AUTHOR_NAME,
)
from .update_ui import DownloadWorker

# ---------------------------------------------------------------------------
# Color tokens
# ---------------------------------------------------------------------------
_BG_SIDEBAR = "rgba(20, 20, 20, 0.6)"
_TEXT_PRIMARY = "#e0e0e0"
_TEXT_SECONDARY = "#999999"
_TEXT_MUTED = "#666666"
_ACCENT_BLUE = "rgba(29, 101, 202, 0.25)"
_ACCENT_BLUE_SOLID = "#1D65CA"
_CARD_BG = "rgba(0, 0, 0, 0.1)"
_CARD_BORDER = "rgba(255, 255, 255, 0.06)"
_INPUT_BG = "rgba(50, 50, 50, 0.8)"
_INPUT_BORDER = "#3a3a3a"

_SCROLL_STYLE = """
    QScrollArea { background: transparent; border: none; }
    QScrollBar:vertical { border: none; background: transparent; width: 6px; }
    QScrollBar::handle:vertical { background: rgba(100,100,100,0.4); border-radius: 3px; min-height: 20px; }
    QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0px; }
    QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical { background: transparent; }
"""

_CARD_STYLE = (
    f"background: {_CARD_BG}; border: 1px solid {_CARD_BORDER}; border-radius: 8px;"
)


# ═══════════════════════════════════════════════════════════════════════════
# Helpers
# ═══════════════════════════════════════════════════════════════════════════

def _section_title(text: str) -> QLabel:
    lbl = QLabel(text)
    lbl.setStyleSheet(
        f"color: {_TEXT_PRIMARY}; font-size: 14px; font-weight: bold; "
        "background: transparent; border: none;"
    )
    return lbl


def _section_scroll() -> QScrollArea:
    sa = QScrollArea()
    sa.setWidgetResizable(True)
    sa.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
    sa.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
    sa.setStyleSheet(_SCROLL_STYLE)
    return sa


def _card_frame() -> QFrame:
    frame = QFrame()
    frame.setStyleSheet(_CARD_STYLE)
    return frame


def _label(text: str, size: int = 11, color: str = _TEXT_SECONDARY, bold: bool = False) -> QLabel:
    lbl = QLabel(text)
    weight = "font-weight: bold;" if bold else ""
    lbl.setStyleSheet(
        f"color: {color}; font-size: {size}px; {weight} "
        "background: transparent; border: none;"
    )
    return lbl


class _ElidingLabel(QLabel):
    """QLabel that truncates text with ellipsis when space is tight."""

    def __init__(self, text: str = "", color: str = _TEXT_PRIMARY, parent=None):
        super().__init__(text, parent)
        self._full_text = text
        self._color = QColor(color)

    def setText(self, text: str):
        self._full_text = text
        super().setText(text)
        self.update()

    def setFullText(self, text: str):
        """Alias for setText — stores full text for elision."""
        self.setText(text)

    def setColor(self, color: str):
        self._color = QColor(color)
        self.update()

    def minimumSizeHint(self):
        return QtCore.QSize(0, super().minimumSizeHint().height())

    def sizeHint(self):
        return QtCore.QSize(0, super().sizeHint().height())

    def paintEvent(self, event):
        from PySide6.QtGui import QPainter, QFontMetrics
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        fm = QFontMetrics(self.font())
        # Account for stylesheet padding
        cm = self.contentsMargins()
        avail = self.width() - cm.left() - cm.right()
        text_rect = self.rect().adjusted(cm.left(), cm.top(), -cm.right(), -cm.bottom())
        elided = fm.elidedText(self._full_text, Qt.ElideLeft, avail)
        painter.setPen(self._color)
        painter.setFont(self.font())
        painter.drawText(text_rect, self.alignment() | Qt.AlignVCenter, elided)
        painter.end()


def _link_button(text: str, url: str) -> QPushButton:
    btn = QPushButton(text)
    btn.setFixedHeight(32)
    btn.setCursor(Qt.PointingHandCursor)
    btn.setStyleSheet(
        "QPushButton { background: transparent; color: #6ba4e8; "
        "border: none; border-radius: 4px; font-size: 11px; text-align: left; padding: 0 12px; }"
        "QPushButton:hover { background: rgba(255,255,255,0.06); }"
    )
    btn.clicked.connect(lambda: webbrowser.open(url))
    return btn


def _divider() -> QFrame:
    """Thin horizontal divider line."""
    line = QFrame()
    line.setFixedHeight(1)
    line.setStyleSheet("background: rgba(255,255,255,0.06); border: none;")
    return line


# ═══════════════════════════════════════════════════════════════════════════
# Avatar Widget
# ═══════════════════════════════════════════════════════════════════════════

class _AvatarFetchWorker(QtCore.QThread):
    """Download an avatar image from a URL on a background thread."""
    finished = Signal(QtGui.QPixmap)

    def __init__(self, url: str):
        super().__init__()
        self._url = url

    def run(self):
        try:
            req = urllib.request.Request(self._url, headers={"User-Agent": "BGEN-Picker/1.0"})
            with urllib.request.urlopen(req, timeout=8) as resp:
                data = resp.read()
            pixmap = QtGui.QPixmap()
            pixmap.loadFromData(data)
            if not pixmap.isNull():
                self.finished.emit(pixmap)
        except Exception:
            pass  # Keep showing initials fallback


class _AvatarWidget(QWidget):
    """Circular avatar with Google profile pic or initials fallback."""

    def __init__(self, size: int = 48, parent=None):
        super().__init__(parent)
        self._size = size
        self._pixmap = None       # Fetched avatar image
        self._initials = "?"
        self._bg_color = QColor(80, 80, 120)
        self._worker = None
        self.setFixedSize(size, size)

    def set_user(self, email: str = "", display_name: str = "", avatar_url: str = ""):
        """Configure avatar from user data."""
        # Compute initials
        name = display_name or email
        if name:
            parts = name.strip().split()
            if len(parts) >= 2:
                self._initials = (parts[0][0] + parts[-1][0]).upper()
            else:
                self._initials = name[0].upper()
        else:
            self._initials = "?"

        # Derive stable color from name
        h = hash(email or display_name or "?")
        hue = abs(h) % 360
        self._bg_color = QColor.fromHsv(hue, 120, 140)

        # Fetch avatar image if URL provided
        if avatar_url:
            self._fetch_avatar(avatar_url)

        self.update()

    def _fetch_avatar(self, url: str):
        if self._worker and self._worker.isRunning():
            return
        self._worker = _AvatarFetchWorker(url)
        self._worker.finished.connect(self._on_avatar_loaded)
        self._worker.start()

    def _on_avatar_loaded(self, pixmap: QtGui.QPixmap):
        # Scale and store
        self._pixmap = pixmap.scaled(
            self._size, self._size,
            Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation
        )
        self._worker = None
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing, True)
        r = self._size

        if self._pixmap and not self._pixmap.isNull():
            # Clip to circle and draw avatar
            path = QtGui.QPainterPath()
            path.addEllipse(0, 0, r, r)
            painter.setClipPath(path)
            # Center-crop the image
            pw, ph = self._pixmap.width(), self._pixmap.height()
            sx = (pw - r) // 2
            sy = (ph - r) // 2
            painter.drawPixmap(0, 0, self._pixmap, sx, sy, r, r)
        else:
            # Initials fallback — colored circle + white text
            painter.setBrush(self._bg_color)
            painter.setPen(Qt.NoPen)
            painter.drawEllipse(0, 0, r, r)

            painter.setPen(QColor(255, 255, 255, 230))
            font = painter.font()
            font.setPixelSize(int(r * 0.38))
            font.setBold(True)
            painter.setFont(font)
            painter.drawText(QtCore.QRect(0, 0, r, r), Qt.AlignCenter, self._initials)

        painter.end()


# ═══════════════════════════════════════════════════════════════════════════
# Sidebar
# ═══════════════════════════════════════════════════════════════════════════

class SettingsSidebar(QFrame):
    """Vertical navigation sidebar with icon + label buttons."""

    section_changed = Signal(int)

    _ITEMS = [
        ("Account", "bgen_settings_icon.png"),
        ("Preferences", "preference_icon.png"),
        ("Updates", "update.png"),
        ("More Info", "manual.png"),
    ]

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedWidth(110)
        self.setStyleSheet(
            f"SettingsSidebar {{ background: {_BG_SIDEBAR}; "
            f"border-right: 1px solid {_CARD_BORDER}; border-radius: 4px; }}"
        )

        layout = QVBoxLayout(self)
        layout.setContentsMargins(6, 10, 6, 10)
        layout.setSpacing(2)

        self.buttons = []
        self.button_group = QButtonGroup(self)
        self.button_group.setExclusive(True)

        for i, (label, icon_name) in enumerate(self._ITEMS):
            btn = QPushButton(f"  {label}")
            btn.setCheckable(True)
            btn.setCursor(Qt.PointingHandCursor)
            btn.setFixedHeight(30)
            btn.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

            icon = UT.get_icon(icon_name, size=14, opacity=0.7)
            if icon:
                btn.setIcon(QIcon(icon))
                btn.setIconSize(QtCore.QSize(14, 14))

            btn.clicked.connect(lambda checked, idx=i: self._on_clicked(idx))
            self.button_group.addButton(btn)
            self.buttons.append(btn)
            layout.addWidget(btn)

        layout.addStretch()

        if self.buttons:
            self.buttons[0].setChecked(True)

        self._apply_styles()

    def _apply_styles(self):
        self.setStyleSheet(
            f"SettingsSidebar {{ background: {_BG_SIDEBAR}; "
            f"border: 1px solid {_CARD_BORDER}; border-radius: 8px; }}"
            "QPushButton { background: transparent; color: #999999; "
            "border: none; border-radius: 6px; font-size: 11px; text-align: left; padding: 4px 8px; }"
            f"QPushButton:hover {{ background: rgba(255,255,255,0.08); color: {_TEXT_PRIMARY}; }}"
            f"QPushButton:checked {{ background: {_ACCENT_BLUE}; color: {_TEXT_PRIMARY}; }}"
        )

    def _on_clicked(self, index: int):
        self.section_changed.emit(index)

    def set_selected_index(self, index: int):
        if 0 <= index < len(self.buttons):
            self.buttons[index].setChecked(True)


# ═══════════════════════════════════════════════════════════════════════════
# Account Section
# ═══════════════════════════════════════════════════════════════════════════

_STATE_SIGNED_OUT = 0
_STATE_EMAIL_ENTRY = 1
_STATE_OTP_ENTRY = 2
_STATE_SIGNED_IN = 3

_LINK_STYLE = (
    f"QPushButton {{ background: transparent; border: none; color: {_TEXT_SECONDARY};font-size: 11px; padding: 2px 0; text-decoration: none; }}"
    f"QPushButton:hover {{ color: {_TEXT_PRIMARY}; text-decoration: underline; }}"
)

_ACTION_BTN_STYLE = (
    f"QPushButton {{ background: {_ACCENT_BLUE_SOLID}; color: white; padding: 6px 16px; border: none; border-radius: 6px; font-size: 12px; font-weight: 500; }}" 
    f"QPushButton:hover {{ background: #2570d4; }}"
    "QPushButton:disabled { background: rgba(29, 101, 202, 0.4); color: rgba(255,255,255,0.5); }"
)

_SIGN_OUT_BTN_STYLE = (
    f"QPushButton {{ background: rgba(255,255,255,0.06); color: #bbbbbb; padding: 6px 16px; border: none; border-radius: 6px; font-size: 11px; }}"
    "border: 1px solid rgba(255,255,255,0.08); border-radius: 4px; font-size: 11px; }"
    "QPushButton:hover { background: rgba(255,255,255,0.12); }"
)

_INPUT_STYLE = (
    f"background: {_INPUT_BG}; color: {_TEXT_PRIMARY}; "
    f"border: 1px solid {_INPUT_BORDER}; border-radius: 4px; "
    "padding: 6px; font-size: 11px;"
)


class ActiveDevicesWidget(QWidget):
    """Displays active device sessions with per-device sign-out.

    Designed as a plain widget (no card frame) to be embedded
    inline within the AccountSection card.
    """

    refresh_requested = Signal()
    sign_out_device_requested = Signal(str)  # session_id

    def __init__(self, current_session_id: str = None, parent=None):
        super().__init__(parent)
        self._current_session_id = current_session_id
        self.setStyleSheet("background: transparent; border: none;")
        self._layout = QVBoxLayout(self)
        self._layout.setContentsMargins(0, 0, 0, 0)
        self._layout.setSpacing(6)

        # Header row
        header_row = QHBoxLayout()
        header_row.addWidget(_label("Active Devices", size=11, color=_TEXT_SECONDARY, bold=True))
        refresh_btn = QPushButton("Refresh")
        refresh_btn.setCursor(Qt.PointingHandCursor)
        refresh_btn.setStyleSheet(_LINK_STYLE)
        refresh_btn.clicked.connect(self.refresh_requested.emit)
        header_row.addStretch()
        header_row.addWidget(refresh_btn)
        self._layout.addLayout(header_row)

        # Device list container
        self._devices_layout = QVBoxLayout()
        self._devices_layout.setSpacing(2)
        self._layout.addLayout(self._devices_layout)

        # Initial loading state
        self._devices_layout.addWidget(
            _label("Loading...", size=10, color=_TEXT_MUTED)
        )

    def set_current_session_id(self, session_id: str):
        self._current_session_id = session_id

    def set_sessions(self, sessions: list):
        """Populate the device list."""
        self._clear_devices()
        if not sessions:
            self._devices_layout.addWidget(
                _label("No active sessions found.", size=11, color=_TEXT_MUTED)
            )
            return
        for session in sessions:
            self._add_device_row(session)

    def show_error(self, message: str):
        self._clear_devices()
        self._devices_layout.addWidget(
            _label(f"Error: {message}", size=11, color="#e05555")
        )

    def _clear_devices(self):
        while self._devices_layout.count():
            item = self._devices_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

    def _add_device_row(self, session: dict):
        session_id = session.get("session_id", "")
        device_info = session.get("device_info", "Unknown device")
        last_active = session.get("last_active_at", "")
        is_current = (session_id == self._current_session_id)

        row = QHBoxLayout()
        row.setSpacing(6)

        # Info column
        info_col = QVBoxLayout()
        info_col.setSpacing(1)

        name_text = device_info
        if is_current:
            name_text += "  (this device)"
        name_color = "#8bc34a" if is_current else _TEXT_PRIMARY
        name_lbl = _ElidingLabel(name_text, color=name_color)
        name_lbl.setStyleSheet(
            f"font-size: 10px; {'font-weight: bold;' if is_current else ''} "
            "background: transparent; border: none;"
        )
        from PySide6.QtWidgets import QSizePolicy
        name_lbl.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        name_lbl.setMinimumWidth(0)
        info_col.addWidget(name_lbl)

        time_text = "Active now" if is_current else self._format_last_active(last_active)
        info_col.addWidget(_label(time_text, size=9, color=_TEXT_MUTED))

        row.addLayout(info_col, 1)

        # Sign-out button (not for current device)
        if not is_current:
            sign_out_btn = QPushButton("Sign Out")
            sign_out_btn.setFixedSize(54, 20)
            sign_out_btn.setCursor(Qt.PointingHandCursor)
            sign_out_btn.setStyleSheet(
                "QPushButton { background: rgba(255,80,80,0.12); color: #e05555; "
                "border: none; border-radius: 3px; font-size: 9px; }"
                "QPushButton:hover { background: rgba(255,80,80,0.22); }"
            )
            sign_out_btn.clicked.connect(
                lambda checked, sid=session_id: self.sign_out_device_requested.emit(sid)
            )
            row.addWidget(sign_out_btn)

        container = QWidget()
        container.setLayout(row)
        container.setStyleSheet(
            "background: rgba(255,255,255,0.02); border-radius: 3px; padding: 3px 4px;"
        )
        self._devices_layout.addWidget(container)

    @staticmethod
    def _format_last_active(iso_timestamp: str) -> str:
        if not iso_timestamp:
            return "Unknown"
        try:
            import datetime
            dt = datetime.datetime.fromisoformat(iso_timestamp.replace("Z", "+00:00"))
            now = datetime.datetime.now(datetime.timezone.utc)
            delta = now - dt
            secs = delta.total_seconds()
            if secs < 60:
                return "Active just now"
            elif secs < 3600:
                mins = int(secs / 60)
                return f"Active {mins} min{'s' if mins != 1 else ''} ago"
            elif secs < 86400:
                hours = int(secs / 3600)
                return f"Active {hours} hour{'s' if hours != 1 else ''} ago"
            else:
                days = int(secs / 86400)
                return f"Active {days} day{'s' if days != 1 else ''} ago"
        except Exception:
            return iso_timestamp


class AccountSection(QWidget):
    """Account section with 4-state email OTP authentication flow."""

    sign_in_requested = Signal()
    sign_out_requested = Signal()
    sign_out_all_requested = Signal()
    google_sign_in_requested = Signal()
    send_otp_requested = Signal(str)
    verify_otp_requested = Signal(str, str)
    refresh_devices_requested = Signal()
    sign_out_device_requested = Signal(str)  # session_id
    owned_items_requested = Signal()         # navigate to owned items page

    def __init__(self, parent=None):
        super().__init__(parent)
        self._state = _STATE_SIGNED_OUT
        self._user_email = None
        self._user_display_name = ""
        self._user_avatar_url = ""
        self._pending_email = ""
        self._error_label = None
        self._action_btn = None
        self._loading = False
        self._current_session_id = None
        self._devices_widget = None
        self._avatar_widget = None
        self._build_ui()

    def _build_ui(self):
        self._layout = QVBoxLayout(self)
        self._layout.setContentsMargins(16, 16, 16, 16)
        self._layout.setSpacing(12)
        self._rebuild()

    def _clear_layout(self):
        while self._layout.count():
            item = self._layout.takeAt(0)
            w = item.widget()
            if w:
                w.hide()
                w.deleteLater()
            sub = item.layout()
            if sub:
                while sub.count():
                    si = sub.takeAt(0)
                    if si.widget():
                        si.widget().hide()
                        si.widget().deleteLater()

    def _rebuild(self):
        self._clear_layout()
        self._error_label = None
        self._action_btn = None
        self._layout.addWidget(_section_title("Account"))

        card = _card_frame()
        card_layout = QVBoxLayout(card)
        card_layout.setContentsMargins(12, 16, 12, 16)
        card_layout.setSpacing(8)

        if self._state == _STATE_SIGNED_IN:
            self._build_signed_in(card_layout)
        elif self._state == _STATE_EMAIL_ENTRY:
            self._build_email_entry(card_layout)
        elif self._state == _STATE_OTP_ENTRY:
            self._build_otp_entry(card_layout)
        else:
            self._build_signed_out(card_layout)

        self._layout.addWidget(card)
        self._layout.addStretch()

    # -- State 0: Signed-out splash ----------------------------------------

    def _build_signed_out(self, layout):
        icons_dir = Path(__file__).parent / "bgen_picker_icons"
        logo_path = icons_dir / "bgen-picker-icon-02.png"
        if logo_path.exists():
            icon_lbl = QLabel()
            icon_lbl.setPixmap(
                QtGui.QPixmap(str(logo_path)).scaled(
                    36, 36, Qt.KeepAspectRatio, Qt.SmoothTransformation
                )
            )
            icon_lbl.setAlignment(Qt.AlignCenter)
            icon_lbl.setStyleSheet("background: transparent; border: none;")
            layout.addWidget(icon_lbl)

        heading = _label("Sign in to BGEN", size=13, color=_TEXT_PRIMARY, bold=True)
        heading.setAlignment(Qt.AlignCenter)
        heading.setWordWrap(True)
        layout.addWidget(heading)

        subtitle = _label(
            "Sync your pickers and access cloud features.",
            size=11, color=_TEXT_SECONDARY,
        )
        subtitle.setAlignment(Qt.AlignCenter)
        subtitle.setWordWrap(True)
        layout.addWidget(subtitle)

        layout.addSpacing(4)

        _google_icon_path = str(Path(__file__).parent / "bgen_picker_icons" / "google_logo.png")
        google_btn = QPushButton(QIcon(_google_icon_path), "  Sign in with Google")
        google_btn.setIconSize(QtCore.QSize(14, 14))
        google_btn.setFixedHeight(30)
        google_btn.setFixedWidth(160)
        google_btn.setCursor(Qt.PointingHandCursor)
        google_btn.setStyleSheet(
            "QPushButton { background: rgba(255,255,255,0.08); color: #e0e0e0; "
            "padding: 6px 16px; border: 1px solid rgba(255,255,255,0.12); "
            "border-radius: 15px; font-size: 11px; }"
            "QPushButton:hover { background: rgba(255,255,255,0.14); }"
        )
        google_btn.clicked.connect(self.google_sign_in_requested.emit)
        layout.addWidget(google_btn, alignment=Qt.AlignCenter)

        or_lbl = _label("or", size=10, color=_TEXT_MUTED)
        or_lbl.setAlignment(Qt.AlignCenter)
        layout.addWidget(or_lbl)

        sign_in_btn = QPushButton("Sign in with Email")
        sign_in_btn.setFixedHeight(30)
        sign_in_btn.setFixedWidth(160)
        sign_in_btn.setCursor(Qt.PointingHandCursor)
        sign_in_btn.setStyleSheet(
            "QPushButton { background: transparent; color: #e0e0e0; "
            "padding: 6px 16px; border: 1px solid rgba(255,255,255,0.12); "
            "border-radius: 15px; font-size: 11px; }"
            "QPushButton:hover { background: rgba(255,255,255,0.08); }"
        )
        sign_in_btn.clicked.connect(self._go_to_email_entry)
        layout.addWidget(sign_in_btn, alignment=Qt.AlignCenter)

        

    # -- State 1: Email entry ----------------------------------------------

    def _build_email_entry(self, layout):
        heading = _label("Enter your email", size=13, color=_TEXT_PRIMARY, bold=True)
        heading.setAlignment(Qt.AlignCenter)
        heading.setWordWrap(True)
        layout.addWidget(heading)

        subtitle = _label(
            "We'll send a 6-digit verification code.",
            size=11, color=_TEXT_SECONDARY,
        )
        subtitle.setAlignment(Qt.AlignCenter)
        subtitle.setWordWrap(True)
        layout.addWidget(subtitle)

        layout.addSpacing(4)

        self._email_input = QLineEdit()
        self._email_input.setPlaceholderText("you@example.com")
        self._email_input.setFixedHeight(28)
        self._email_input.setStyleSheet(_INPUT_STYLE)
        if self._pending_email:
            self._email_input.setText(self._pending_email)
        layout.addWidget(self._email_input)

        # Error label (hidden by default)
        self._error_label = _label("", size=11, color="#e05555")
        self._error_label.setAlignment(Qt.AlignCenter)
        self._error_label.setWordWrap(True)
        self._error_label.hide()
        layout.addWidget(self._error_label)

        self._action_btn = QPushButton("Send Code")
        self._action_btn.setFixedHeight(30)
        self._action_btn.setCursor(Qt.PointingHandCursor)
        self._action_btn.setStyleSheet(_ACTION_BTN_STYLE)
        self._action_btn.clicked.connect(self._on_send_code)
        layout.addWidget(self._action_btn)

        back_btn = QPushButton("Back")
        back_btn.setCursor(Qt.PointingHandCursor)
        back_btn.setStyleSheet(_LINK_STYLE)
        back_btn.clicked.connect(self._go_to_signed_out)
        layout.addWidget(back_btn, alignment=Qt.AlignCenter)

    # -- State 2: OTP code entry -------------------------------------------

    def _build_otp_entry(self, layout):
        heading = _label("Enter verification code", size=13, color=_TEXT_PRIMARY, bold=True)
        heading.setAlignment(Qt.AlignCenter)
        heading.setWordWrap(True)
        layout.addWidget(heading)

        subtitle = _label(
            f"Code sent to {self._pending_email}",
            size=11, color=_TEXT_MUTED,
        )
        subtitle.setAlignment(Qt.AlignCenter)
        subtitle.setWordWrap(True)
        layout.addWidget(subtitle)

        layout.addSpacing(4)

        self._code_input = QLineEdit()
        self._code_input.setPlaceholderText("000000")
        self._code_input.setMaxLength(6)
        self._code_input.setFixedHeight(28)
        self._code_input.setMaximumWidth(160)
        self._code_input.setAlignment(Qt.AlignCenter)
        self._code_input.setStyleSheet(
            _INPUT_STYLE + " font-size: 14px; letter-spacing: 6px;"
        )
        layout.addWidget(self._code_input, alignment=Qt.AlignCenter)

        # Error label (hidden by default)
        self._error_label = _label("", size=11, color="#e05555")
        self._error_label.setAlignment(Qt.AlignCenter)
        self._error_label.setWordWrap(True)
        self._error_label.hide()
        layout.addWidget(self._error_label)

        self._action_btn = QPushButton("Verify")
        self._action_btn.setFixedHeight(30)
        self._action_btn.setMaximumWidth(200)
        self._action_btn.setCursor(Qt.PointingHandCursor)
        self._action_btn.setStyleSheet(_ACTION_BTN_STYLE)
        self._action_btn.clicked.connect(self._on_verify)
        layout.addWidget(self._action_btn, alignment=Qt.AlignCenter)

        # Resend / Back row
        links_row = QHBoxLayout()
        links_row.setSpacing(12)
        links_row.setContentsMargins(0, 0, 0, 0)

        resend_btn = QPushButton("Resend Code")
        resend_btn.setCursor(Qt.PointingHandCursor)
        resend_btn.setStyleSheet(_LINK_STYLE)
        resend_btn.clicked.connect(self._on_resend)
        links_row.addStretch()
        links_row.addWidget(resend_btn)

        sep = _label("|", size=11, color=_TEXT_MUTED)
        links_row.addWidget(sep)

        back_btn = QPushButton("Back")
        back_btn.setCursor(Qt.PointingHandCursor)
        back_btn.setStyleSheet(_LINK_STYLE)
        back_btn.clicked.connect(self._go_to_email_entry)
        links_row.addWidget(back_btn)
        links_row.addStretch()

        layout.addLayout(links_row)

    # -- State 3: Signed in ------------------------------------------------

    def _build_signed_in(self, layout):
        # -- Profile header: avatar + name/email ---
        profile_row = QHBoxLayout()
        profile_row.setSpacing(10)

        self._avatar_widget = _AvatarWidget(size=48)
        self._avatar_widget.set_user(
            email=self._user_email or "",
            display_name=self._user_display_name,
            avatar_url=self._user_avatar_url,
        )
        profile_row.addWidget(self._avatar_widget)

        info_col = QVBoxLayout()
        info_col.setSpacing(2)
        display = self._user_display_name or "BGEN User"
        name_lbl = _ElidingLabel(display, color=_TEXT_PRIMARY)
        name_lbl.setStyleSheet("font-size: 13px; font-weight: bold; background: transparent; border: none;")
        name_lbl.setMinimumWidth(0)
        email_lbl = _ElidingLabel(self._user_email or "", color=_TEXT_SECONDARY)
        email_lbl.setStyleSheet("font-size: 11px; background: transparent; border: none;")
        email_lbl.setMinimumWidth(0)
        info_col.addWidget(name_lbl)
        info_col.addWidget(email_lbl)
        profile_row.addLayout(info_col, 1)

        layout.addLayout(profile_row)

        # -- Divider ---
        layout.addSpacing(4)
        layout.addWidget(_divider())
        layout.addSpacing(4)

        # -- Active Devices (inline, no nested card) ---
        self._devices_widget = ActiveDevicesWidget(
            current_session_id=self._current_session_id
        )
        self._devices_widget.refresh_requested.connect(self.refresh_devices_requested.emit)
        self._devices_widget.sign_out_device_requested.connect(self.sign_out_device_requested.emit)
        layout.addWidget(self._devices_widget)

        # -- Divider ---
        layout.addSpacing(4)
        layout.addWidget(_divider())
        layout.addSpacing(4)

        # -- Owned Items row ---
        owned_row = QHBoxLayout()
        owned_row.setSpacing(2)
        owned_row.setContentsMargins(4, 4, 4, 4)
        owned_row.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        _icons_dir = Path(__file__).parent / "bgen_picker_icons"
        owned_icon = QLabel()
        _star_pix = QtGui.QPixmap(str(_icons_dir / "star-white-icon.png"))
        if not _star_pix.isNull():
            owned_icon.setPixmap(_star_pix.scaled(
                12, 12, Qt.KeepAspectRatio, Qt.SmoothTransformation
            ))
        owned_icon.setStyleSheet("background: transparent; border: none;")
        #owned_icon.setFixedWidth(18)
        
        owned_lbl = QLabel("Owned Items")
        owned_lbl.setStyleSheet(
            f"color: {_TEXT_PRIMARY}; font-size: 12px; "
            "background: transparent; border: none;"
        )
        
        self._owned_count_lbl = QLabel("")
        self._owned_count_lbl.setStyleSheet(
            "color: #888888; font-size: 11px; "
            "background: transparent; border: none; padding: 0 4px;"
        )
        
        chevron = QLabel()
        _arrow_pix = QtGui.QPixmap(str(_icons_dir / "arrow_right_icon.png"))
        if not _arrow_pix.isNull():
            chevron.setPixmap(_arrow_pix.scaled(
                12, 12, Qt.KeepAspectRatio, Qt.SmoothTransformation
            ))
        chevron.setStyleSheet("background: transparent; border: none;")
        

        owned_wrapper = QWidget()
        owned_wrapper.setMinimumWidth(0)
        owned_wrapper.setLayout(owned_row)
        owned_wrapper.setCursor(Qt.PointingHandCursor)
        owned_wrapper.setStyleSheet(
            "QWidget { background: rgba(255,255,255,0.04); "
            "border: 1px solid rgba(255,255,255,0.06); "
            "border-radius: 6px; padding: 2px 4px; }"
            "QWidget:hover { background: rgba(255,255,255,0.08); "
            "border-color: rgba(255,255,255,0.12); }"
        )
        owned_wrapper.mousePressEvent = lambda e: self.owned_items_requested.emit()

        owned_row.addWidget(owned_icon)
        owned_row.addWidget(owned_lbl)
        owned_row.addWidget(self._owned_count_lbl)
        owned_row.addStretch()
        owned_row.addWidget(chevron)


        layout.addWidget(owned_wrapper)

        layout.addSpacing(4)
        layout.addWidget(_divider())
        layout.addSpacing(4)

        # -- Sign-out zone ---
        sign_out_btn = QPushButton("Sign Out")
        sign_out_btn.setFixedHeight(26)
        sign_out_btn.setMaximumWidth(200)
        sign_out_btn.setCursor(Qt.PointingHandCursor)
        sign_out_btn.setStyleSheet(_SIGN_OUT_BTN_STYLE)
        sign_out_btn.clicked.connect(self.sign_out_requested.emit)
        layout.addWidget(sign_out_btn, alignment=Qt.AlignCenter)

        sign_out_all_btn = QPushButton("Sign out all devices")
        sign_out_all_btn.setCursor(Qt.PointingHandCursor)
        sign_out_all_btn.setStyleSheet(_LINK_STYLE)
        sign_out_all_btn.clicked.connect(self._confirm_sign_out_all)
        layout.addWidget(sign_out_all_btn, alignment=Qt.AlignCenter)

    # -- Navigation helpers ------------------------------------------------

    def _go_to_signed_out(self):
        self._state = _STATE_SIGNED_OUT
        self._pending_email = ""
        self._loading = False
        self._rebuild()

    def _go_to_email_entry(self):
        self._state = _STATE_EMAIL_ENTRY
        self._loading = False
        self._rebuild()

    # -- Action handlers ---------------------------------------------------

    def _on_send_code(self):
        email = self._email_input.text().strip()
        if not email:
            self.show_error("Please enter your email address.")
            return
        self._pending_email = email
        self._loading = True
        self._action_btn.setEnabled(False)
        self._action_btn.setText("Sending...")
        if self._error_label:
            self._error_label.hide()
        self.send_otp_requested.emit(email)

    def _on_verify(self):
        code = self._code_input.text().strip()
        if not code:
            self.show_error("Please enter the verification code.")
            return
        self._loading = True
        self._action_btn.setEnabled(False)
        self._action_btn.setText("Verifying...")
        if self._error_label:
            self._error_label.hide()
        self.verify_otp_requested.emit(self._pending_email, code)

    def _on_resend(self):
        if self._error_label:
            self._error_label.hide()
        self.send_otp_requested.emit(self._pending_email)

    def _confirm_sign_out_all(self):
        from . import custom_dialog as CD
        dialog = CD.CustomDialog(
            self, title="Sign Out All Devices", size=(280, 100),
        )
        msg = QLabel("This will sign you out on all devices.\nContinue?")
        msg.setWordWrap(True)
        msg.setAlignment(Qt.AlignCenter)
        dialog.add_widget(msg)
        dialog.add_button_box()
        if dialog.exec() == dialog.Accepted:
            self.sign_out_all_requested.emit()

    # -- Public API --------------------------------------------------------

    def show_otp_entry(self):
        """Transition to OTP code entry (called when OTP sent successfully)."""
        self._state = _STATE_OTP_ENTRY
        self._loading = False
        self._rebuild()

    def show_error(self, message: str):
        """Show inline error message and re-enable action button."""
        self._loading = False
        if self._error_label:
            self._error_label.setText(message)
            self._error_label.show()
        if self._action_btn:
            self._action_btn.setEnabled(True)
            if self._state == _STATE_EMAIL_ENTRY:
                self._action_btn.setText("Send Code")
            elif self._state == _STATE_OTP_ENTRY:
                self._action_btn.setText("Verify")

    def set_signed_in(self, email: str, display_name: str = "", avatar_url: str = ""):
        """Transition to signed-in state."""
        self._state = _STATE_SIGNED_IN
        self._user_email = email
        self._user_display_name = display_name
        self._user_avatar_url = avatar_url
        self._pending_email = ""
        self._loading = False
        self._rebuild()

    def set_owned_count(self, count: int):
        """Update the owned items count badge."""
        if hasattr(self, "_owned_count_lbl") and self._owned_count_lbl:
            self._owned_count_lbl.setText(f"{count}" if count else "")

    def set_signed_out(self):
        """Transition to signed-out splash."""
        self._state = _STATE_SIGNED_OUT
        self._user_email = None
        self._user_display_name = ""
        self._user_avatar_url = ""
        self._pending_email = ""
        self._loading = False
        self._current_session_id = None
        self._rebuild()

    def set_current_session_id(self, session_id: str):
        """Store the current device's session_id for the active devices list."""
        self._current_session_id = session_id
        if self._devices_widget:
            self._devices_widget.set_current_session_id(session_id)

    def update_devices(self, sessions: list):
        """Populate the active devices list with session data."""
        if self._devices_widget:
            self._devices_widget.set_sessions(sessions)

    def show_devices_error(self, message: str):
        """Show an error in the active devices list."""
        if self._devices_widget:
            self._devices_widget.show_error(message)


# ═══════════════════════════════════════════════════════════════════════════
# Preferences Section
# ═══════════════════════════════════════════════════════════════════════════

class PreferencesSection(QWidget):
    """Library path, downloads path, and general preferences."""

    def __init__(self, browse_callback, open_folder_callback,
                 browse_downloads_callback=None, open_downloads_callback=None,
                 parent=None):
        super().__init__(parent)
        self._browse_callback = browse_callback
        self._open_folder_callback = open_folder_callback
        self._browse_downloads_callback = browse_downloads_callback or (lambda: None)
        self._open_downloads_callback = open_downloads_callback or (lambda: None)
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(12)

        layout.addWidget(_section_title("Preferences"))

        _path_input_style = (
            f"background: {_INPUT_BG}; color: {_TEXT_PRIMARY}; "
            f"border: 1px solid {_INPUT_BORDER}; border-radius: 4px; "
            "padding: 4px; font-size: 11px;"
        )
        _browse_btn_style = (
            "QPushButton { background: rgba(255,255,255,0.08); color: #dddddd; "
            f"border: 1px solid {_INPUT_BORDER}; border-radius: 4px; }} "
            "QPushButton:hover { background: rgba(255,255,255,0.15); }"
        )
        _open_btn_style = (
            "QPushButton { background: rgba(255,255,255,0.06); color: #bbbbbb; "
            "border: 1px solid rgba(255,255,255,0.08); border-radius: 4px; font-size: 11px; }"
            "QPushButton:hover { background: rgba(255,255,255,0.12); }"
        )

        # -- Picker Library card --
        card = _card_frame()
        card_layout = QVBoxLayout(card)
        card_layout.setContentsMargins(12, 12, 12, 12)
        card_layout.setSpacing(8)

        card_layout.addWidget(_label("Picker Library", size=12, color="#bbbbbb", bold=True))
        _lib_desc = _label(
            "Where your .bpicker files are stored and managed",
            size=10, color=_TEXT_MUTED,
        )
        _lib_desc.setWordWrap(True)
        card_layout.addWidget(_lib_desc)

        path_row = QHBoxLayout()
        path_row.setSpacing(4)
        self.lib_path_label = _ElidingLabel()
        self.lib_path_label.setFixedHeight(26)
        self.lib_path_label.setStyleSheet(_path_input_style)
        self.lib_path_label.setToolTip("")

        browse_btn = QPushButton("...")
        browse_btn.setFixedSize(28, 26)
        browse_btn.setCursor(Qt.PointingHandCursor)
        browse_btn.setStyleSheet(_browse_btn_style)
        browse_btn.clicked.connect(self._browse_callback)

        path_row.addWidget(self.lib_path_label, 1)
        path_row.addWidget(browse_btn)
        card_layout.addLayout(path_row)

        open_btn = QPushButton("Open Picker Library Folder")
        open_btn.setFixedHeight(26)
        open_btn.setMaximumWidth(200)
        open_btn.setCursor(Qt.PointingHandCursor)
        open_btn.setStyleSheet(_open_btn_style)
        open_btn.clicked.connect(self._open_folder_callback)
        card_layout.addWidget(open_btn)

        layout.addWidget(card)

        # -- Asset Downloads card --
        dl_card = _card_frame()
        dl_card_layout = QVBoxLayout(dl_card)
        dl_card_layout.setContentsMargins(12, 12, 12, 12)
        dl_card_layout.setSpacing(8)

        dl_card_layout.addWidget(_label("Asset Downloads", size=12, color="#bbbbbb", bold=True))
        _dl_desc = _label(
            "Where non-picker files (rigs, models, etc.) are saved after purchase",
            size=10, color=_TEXT_MUTED,
        )
        _dl_desc.setWordWrap(True)
        dl_card_layout.addWidget(_dl_desc)

        dl_path_row = QHBoxLayout()
        dl_path_row.setSpacing(4)
        self.dl_path_label = _ElidingLabel()
        self.dl_path_label.setFixedHeight(26)
        self.dl_path_label.setStyleSheet(_path_input_style)
        self.dl_path_label.setToolTip("")

        dl_browse_btn = QPushButton("...")
        dl_browse_btn.setFixedSize(28, 26)
        dl_browse_btn.setCursor(Qt.PointingHandCursor)
        dl_browse_btn.setStyleSheet(_browse_btn_style)
        dl_browse_btn.clicked.connect(self._browse_downloads_callback)

        dl_path_row.addWidget(self.dl_path_label, 1)
        dl_path_row.addWidget(dl_browse_btn)
        dl_card_layout.addLayout(dl_path_row)

        dl_open_btn = QPushButton("Open Asset Downloads Folder")
        dl_open_btn.setFixedHeight(26)
        dl_open_btn.setMaximumWidth(220)
        dl_open_btn.setCursor(Qt.PointingHandCursor)
        dl_open_btn.setStyleSheet(_open_btn_style)
        dl_open_btn.clicked.connect(self._open_downloads_callback)
        dl_card_layout.addWidget(dl_open_btn)

        layout.addWidget(dl_card)

        # -- Window Behavior card --
        wb_card = _card_frame()
        wb_layout = QVBoxLayout(wb_card)
        wb_layout.setContentsMargins(12, 12, 12, 12)
        wb_layout.setSpacing(8)

        wb_layout.addWidget(_label("Window Behavior", size=12, color="#bbbbbb", bold=True))
        _wb_desc = _label(
            "Control whether the picker stays visible when Blender loses focus",
            size=10, color=_TEXT_MUTED,
        )
        _wb_desc.setWordWrap(True)
        wb_layout.addWidget(_wb_desc)

        # Toggle row
        toggle_row = QHBoxLayout()
        toggle_row.setSpacing(8)
        self._aot_label = _label("Always on Top", size=11, color=_TEXT_PRIMARY)
        self._aot_toggle = QPushButton()
        self._aot_toggle.setCheckable(True)
        self._aot_toggle.setFixedSize(40, 22)
        self._aot_toggle.setCursor(Qt.PointingHandCursor)
        self._aot_toggle.setStyleSheet(self._toggle_style())
        self._aot_toggle.toggled.connect(self._on_always_on_top_toggled)

        toggle_row.addWidget(self._aot_label)
        toggle_row.addStretch()
        toggle_row.addWidget(self._aot_toggle)
        wb_layout.addLayout(toggle_row)

        _aot_hint = _label(
            "When off, the picker hides when you switch to another application.",
            size=10, color=_TEXT_MUTED,
        )
        _aot_hint.setWordWrap(True)
        wb_layout.addWidget(_aot_hint)

        layout.addWidget(wb_card)
        layout.addStretch()

        # Load current paths and preferences
        from .library_manager import LibraryManager
        self._set_path_label(self.lib_path_label, str(LibraryManager.get_library_path()))
        self._set_path_label(self.dl_path_label, str(LibraryManager.get_downloads_path()))

        # Load always-on-top state
        self._aot_toggle.setChecked(LibraryManager.get_always_on_top())

    def _on_always_on_top_toggled(self, checked):
        """Persist the always-on-top preference when toggled."""
        from .library_manager import LibraryManager
        LibraryManager.set_always_on_top(checked)
        # Invalidate visibility manager cache so change takes effect immediately
        from .blender_main import PickerVisibilityManager
        vm = PickerVisibilityManager.get_instance()
        vm._always_on_top_cache = checked
        vm._always_on_top_cache_time = 0

    @staticmethod
    def _toggle_style():
        """Return stylesheet for a small iOS-style toggle button."""
        return (
            "QPushButton {"
            "  background: rgba(255,255,255,0.10); border: 1px solid rgba(255,255,255,0.15);"
            "  border-radius: 11px;"
            "}"
            "QPushButton:checked {"
            "  background: #4C8BF5; border: 1px solid #4C8BF5;"
            "}"
            "QPushButton::indicator { width: 0; height: 0; }"
        )

    @staticmethod
    def _set_path_label(label, path):
        """Set text and tooltip on an eliding path label."""
        label.setFullText(path)
        label.setToolTip(path)


# ═══════════════════════════════════════════════════════════════════════════
# Updates Section
# ═══════════════════════════════════════════════════════════════════════════

class UpdatesSection(QWidget):
    """Inline update UI — migrated from UpdateWidget."""

    _latest_tag_cache = None
    _last_check_time = 0
    _cache_duration = 3600  # 1 hour

    def __init__(self, parent_window=None, parent=None):
        super().__init__(parent)
        self._parent_window = parent_window
        self.releases = []
        self.download_worker = None
        self.repo_url = GITHUB_URL
        self.folder_path = "blender/ft_anim_picker"
        self.LAST_AVAILABLE_VERSION = "1.7.0"
        self._build_ui()
        QTimer.singleShot(500, self.load_releases)

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(12)

        layout.addWidget(_section_title("Updates"))

        # -- Version card --
        card = _card_frame()
        card_layout = QVBoxLayout(card)
        card_layout.setContentsMargins(12, 12, 12, 12)
        card_layout.setSpacing(6)

        # Current version
        import ft_anim_picker.src as _pkg
        current = _pkg.__version__

        row1 = QHBoxLayout()
        row1.addWidget(_label("Current Version"))
        self.current_version_label = _label(f"v{current}", color=_TEXT_PRIMARY, bold=True)
        row1.addStretch()
        row1.addWidget(self.current_version_label)
        card_layout.addLayout(row1)

        row2 = QHBoxLayout()
        row2.addWidget(_label("Latest Version"))
        self.latest_version_label = _label("Checking...", color=_TEXT_MUTED)
        row2.addStretch()
        row2.addWidget(self.latest_version_label)
        card_layout.addLayout(row2)

        layout.addWidget(card)

        # -- Releases dropdown --
        releases_row = QHBoxLayout()
        releases_row.setSpacing(8)
        releases_row.addWidget(_label("Available Versions:", color=_TEXT_PRIMARY, bold=True))
        self.releases_combo = QComboBox()
        self.releases_combo.setFixedSize(90, 26)
        self.releases_combo.setStyleSheet(
            "QComboBox { background-color: #2a2a2a; color: #dddddd; "
            "border: 1px solid #555555; border-radius: 3px; padding: 4px; }"
            "QComboBox:hover { border-color: #4ca3fe; }"
            "QComboBox::drop-down { border: none; width: 20px; }"
            "QComboBox::down-arrow { image: none; border: 2px solid #aaaaaa; "
            "border-top: none; border-left: none; width: 6px; height: 6px; margin-right: 6px; }"
            "QComboBox QAbstractItemView { background-color: #2a2a2a; "
            "border: 1px solid #555555; selection-background-color: #4ca3fe; color: #dddddd; }"
        )
        releases_row.addWidget(self.releases_combo)
        releases_row.addStretch()
        layout.addLayout(releases_row)

        # -- Update button --
        self.update_btn = QPushButton("Update")
        self.update_btn.setFixedHeight(30)
        self.update_btn.setMaximumWidth(200)
        self.update_btn.setEnabled(False)
        self.update_btn.setCursor(Qt.PointingHandCursor)
        self.update_btn.setStyleSheet(
            "QPushButton { background-color: #7db305; color: white; "
            "border: none; border-radius: 6px; font-weight: bold; font-size: 12px; }"
            "QPushButton:hover { background-color: #97d906; }"
            "QPushButton:disabled { background-color: #444444; color: #888888; }"
        )
        self.update_btn.clicked.connect(self.download_release)
        layout.addWidget(self.update_btn)

        # -- Progress bar --
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        self.progress_bar.setStyleSheet(
            "QProgressBar { border: 1px solid #555555; border-radius: 4px; "
            "text-align: center; background-color: #2a2a2a; color: #dddddd; }"
            "QProgressBar::chunk { background-color: #4ca3fe; border-radius: 4px; }"
        )
        layout.addWidget(self.progress_bar)

        # -- Status label --
        self.status_label = _label("", size=10, color=_TEXT_MUTED)
        self.status_label.setWordWrap(True)
        layout.addWidget(self.status_label)

        # -- Success container (hidden by default) --
        self.success_container = QWidget()
        self.success_container.setVisible(False)
        success_layout = QVBoxLayout(self.success_container)
        success_layout.setContentsMargins(0, 8, 0, 0)
        success_layout.setSpacing(6)

        success_msg = _label("Update Successful!", size=14, color=_TEXT_PRIMARY, bold=True)
        success_msg.setAlignment(Qt.AlignCenter)
        success_layout.addWidget(success_msg)

        restart_msg = _label("Please restart Blender to complete the update.", size=11, color=_TEXT_SECONDARY)
        restart_msg.setAlignment(Qt.AlignCenter)
        restart_msg.setWordWrap(True)
        success_layout.addWidget(restart_msg)

        layout.addWidget(self.success_container)
        layout.addStretch()

    # -- Release fetching --------------------------------------------------

    def load_releases(self):
        try:
            repo_url = self.repo_url
            if repo_url.endswith(".git"):
                repo_url = repo_url[:-4]

            parts = repo_url.replace("https://github.com/", "").split("/")
            if len(parts) < 2:
                self.status_label.setText("Error: Invalid repository URL")
                return

            owner, repo = parts[0], parts[1]
            api_url = f"https://api.github.com/repos/{owner}/{repo}/releases"
            headers = {"User-Agent": "GitReleaseDownloader/1.0"}
            req = urllib.request.Request(api_url, headers=headers)

            with urllib.request.urlopen(req) as response:
                releases_data = json.loads(response.read().decode())

            self.releases_combo.clear()
            self.releases = []

            if not releases_data:
                self.status_label.setText("No releases found")
                return

            latest_tag = None
            for release in releases_data:
                tag_name = release["tag_name"]
                name = release["name"] if release["name"] else tag_name
                self.releases.append({
                    "tag": tag_name,
                    "name": name,
                    "url": release["html_url"],
                    "assets": release["assets"],
                })
                if self.is_newer_version(tag_name, self.LAST_AVAILABLE_VERSION):
                    self.releases_combo.addItem(tag_name)
                if latest_tag is None:
                    latest_tag = tag_name

            self.update_btn.setEnabled(self.releases_combo.count() > 0)

            # Update latest version label
            if latest_tag:
                self.latest_version_label.setText(f"v{latest_tag.lstrip('v')}")
                import ft_anim_picker.src as _pkg
                current = _pkg.__version__
                if self.is_newer_version(latest_tag, current):
                    self.latest_version_label.setStyleSheet(
                        "color: #7db305; font-size: 11px; font-weight: bold; "
                        "background: transparent; border: none;"
                    )
                else:
                    self.latest_version_label.setStyleSheet(
                        f"color: {_TEXT_PRIMARY}; font-size: 11px; font-weight: bold; "
                        "background: transparent; border: none;"
                    )

            # Update cache
            import time
            UpdatesSection._latest_tag_cache = latest_tag
            UpdatesSection._last_check_time = time.time()

        except Exception as e:
            self.status_label.setText(f"Error loading releases: {e}")
            self.latest_version_label.setText("Error")
            self.latest_version_label.setStyleSheet(
                "color: #cc4444; font-size: 11px; background: transparent; border: none;"
            )

    # -- Version helpers ---------------------------------------------------

    @staticmethod
    def parse_version(version_string):
        import re
        version = str(version_string).strip().lstrip("v")
        numbers = re.findall(r"\d+", version)
        return tuple(map(int, numbers)) if numbers else (0,)

    @staticmethod
    def is_newer_version(latest, current):
        return UpdatesSection.parse_version(latest) > UpdatesSection.parse_version(current)

    def get_latest_tag(self):
        """Return cached latest tag, or fetch if cache expired."""
        import time
        if (self._latest_tag_cache is not None
                and time.time() - self._last_check_time < self._cache_duration):
            return self._latest_tag_cache

        # Trigger async load; return cached value (may be None)
        QTimer.singleShot(0, self.load_releases)
        return self._latest_tag_cache

    # -- Download ----------------------------------------------------------

    def download_release(self):
        if not self.releases or self.releases_combo.currentIndex() < 0:
            return

        release = self.releases[self.releases_combo.currentIndex()]

        if not release["assets"]:
            tag = release["tag"]
            parts = self.repo_url.replace("https://github.com/", "").split("/")
            owner, repo = parts[0], parts[1]
            asset = {
                "name": os.path.basename(self.folder_path) if self.folder_path else f"{repo}-{tag}.zip",
                "browser_download_url": f"https://github.com/{owner}/{repo}/archive/refs/tags/{tag}.zip",
            }
        else:
            asset = release["assets"][0]

        script_dir = os.path.normpath(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))
        download_path = script_dir

        self.progress_bar.setValue(0)
        self.progress_bar.setVisible(True)
        self.update_btn.setEnabled(False)
        self.status_label.setText(f"Downloading {release['tag']}...")

        self.download_worker = DownloadWorker(
            self.repo_url, release["tag"], download_path, self.folder_path
        )
        self.download_worker.progress_updated.connect(self._on_progress)
        self.download_worker.status_updated.connect(self._on_status)
        self.download_worker.download_complete.connect(self._on_complete)
        self.download_worker.start()

    def _on_progress(self, value):
        self.progress_bar.setValue(value)

    def _on_status(self, message):
        self.status_label.setText(message)

    def _on_complete(self, success, message):
        self.progress_bar.setVisible(False)
        self.update_btn.setEnabled(True)
        if success:
            self.status_label.setText("")
            self.success_container.setVisible(True)
            self.update_btn.setVisible(False)
            self.releases_combo.parent()  # keep alive
        else:
            self.status_label.setText(f"Failed: {message}")


# ═══════════════════════════════════════════════════════════════════════════
# More Info Section
# ═══════════════════════════════════════════════════════════════════════════

class MoreInfoSection(QWidget):
    """App info, version, and useful links."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(12)

        layout.addWidget(_section_title("More Info"))

        # -- App info card --
        card = _card_frame()
        card_layout = QVBoxLayout(card)
        card_layout.setContentsMargins(12, 16, 12, 16)
        card_layout.setSpacing(6)
        card_layout.setAlignment(Qt.AlignCenter)

        icons_dir = Path(__file__).parent / "bgen_picker_icons"
        logo_path = icons_dir / "bgen-picker-icon-02.png"
        if logo_path.exists():
            icon_lbl = QLabel()
            icon_lbl.setPixmap(
                QtGui.QPixmap(str(logo_path)).scaled(
                    48, 48, Qt.KeepAspectRatio, Qt.SmoothTransformation
                )
            )
            icon_lbl.setAlignment(Qt.AlignCenter)
            icon_lbl.setStyleSheet("background: transparent; border: none;")
            card_layout.addWidget(icon_lbl)

        name_lbl = _label("BGEN Picker", size=14, color=_TEXT_PRIMARY, bold=True)
        name_lbl.setAlignment(Qt.AlignCenter)
        card_layout.addWidget(name_lbl)

        import ft_anim_picker.src as _pkg
        ver_lbl = _label(f"v{_pkg.__version__}", size=12, color=_TEXT_SECONDARY)
        ver_lbl.setAlignment(Qt.AlignCenter)
        card_layout.addWidget(ver_lbl)

        author_lbl = _label(f"by {AUTHOR_NAME}", size=11, color=_TEXT_SECONDARY)
        author_lbl.setAlignment(Qt.AlignCenter)
        card_layout.addWidget(author_lbl)

        layout.addWidget(card)

        # -- Links card --
        links_card = _card_frame()
        links_layout = QVBoxLayout(links_card)
        links_layout.setContentsMargins(12, 8, 12, 8)
        links_layout.setSpacing(0)

        links_layout.addWidget(_link_button("GitHub", GITHUB_URL))
        links_layout.addWidget(_link_button("Report a Bug", GITHUB_ISSUES_URL))

        layout.addWidget(links_card)
        layout.addStretch()


# ═══════════════════════════════════════════════════════════════════════════
# Settings Page (top-level)
# ═══════════════════════════════════════════════════════════════════════════

class SettingsPage(QWidget):
    """Settings page with sidebar navigation and four content sections."""

    def __init__(self, parent_window=None, browse_callback=None, open_folder_callback=None,
                 browse_downloads_callback=None, open_downloads_callback=None, parent=None):
        super().__init__(parent)
        self._parent_window = parent_window
        self.setStyleSheet("background: transparent;")

        main_layout = QHBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # Sidebar
        self.sidebar = SettingsSidebar()
        main_layout.addWidget(self.sidebar)

        # Content stack
        self.content_stack = QStackedWidget()
        self.content_stack.setStyleSheet("background: transparent; border: none;")

        # Sections
        self.account = AccountSection()
        self.preferences = PreferencesSection(
            browse_callback=browse_callback or (lambda: None),
            open_folder_callback=open_folder_callback or (lambda: None),
            browse_downloads_callback=browse_downloads_callback or (lambda: None),
            open_downloads_callback=open_downloads_callback or (lambda: None),
        )
        self.updates = UpdatesSection(parent_window=parent_window)
        self.more_info = MoreInfoSection()

        # Wrap each in scroll area
        for section in (self.account, self.preferences, self.updates, self.more_info):
            sa = _section_scroll()
            sa.setWidget(section)
            self.content_stack.addWidget(sa)

        main_layout.addWidget(self.content_stack)

        # Wire sidebar
        self.sidebar.section_changed.connect(self.content_stack.setCurrentIndex)

    # -- Public API --------------------------------------------------------

    def update_library_path_display(self, path: str):
        PreferencesSection._set_path_label(self.preferences.lib_path_label, path)

    def update_downloads_path_display(self, path: str):
        PreferencesSection._set_path_label(self.preferences.dl_path_label, path)

    def on_page_shown(self):
        """Called when the settings page becomes visible."""
        # Refresh path displays
        from .library_manager import LibraryManager
        PreferencesSection._set_path_label(
            self.preferences.lib_path_label, str(LibraryManager.get_library_path())
        )
        PreferencesSection._set_path_label(
            self.preferences.dl_path_label, str(LibraryManager.get_downloads_path())
        )

    def set_section(self, index: int):
        """Programmatically switch to a specific section (0-3)."""
        self.sidebar.set_selected_index(index)
        self.content_stack.setCurrentIndex(index)

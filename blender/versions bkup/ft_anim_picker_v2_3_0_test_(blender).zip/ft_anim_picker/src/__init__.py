"""FT Anim Picker - A powerful animation picker tool for Maya and Blender

Part of the Floating Tools (FT) collection.
"""

__version__ = '2.2.8'
__author__ = 'Floating Tools'

# Note: Import functions only when explicitly needed to avoid circular imports
# from .blender_main import open  # Available but not auto-imported

"""
UI Controls widget for the curve editor.

Provides a toolbar-style widget with:
- Tool selection buttons (Pen, Node, Rectangle, Ellipse)
- Point type buttons (Corner, Smooth, Symmetric)
- Action buttons (Done, Cancel)

Styled to match TransformControlsWidget for visual consistency.
"""

from PySide6 import QtWidgets, QtCore, QtGui
from PySide6.QtCore import QTimer, QPropertyAnimation, QEasingCurve, Signal

from .curve_data import PointType
from .curve_tools import EditorTool

# Import utils for icons if available
try:
    from .. import utils as UT
    HAS_UTILS = True
except ImportError:
    HAS_UTILS = False


class CurveEditorControlsWidget(QtWidgets.QWidget):
    """
    Toolbar widget for curve editor controls.
    
    Signals:
        toolChanged(EditorTool): Emitted when active tool changes
        pointTypeChanged(PointType): Emitted when point type selection changes
        editingFinished(): Emitted when user clicks Done
        editingCancelled(): Emitted when user clicks Cancel
    """
    
    toolChanged = Signal(object)  # EditorTool
    pointTypeChanged = Signal(object)  # PointType
    editingFinished = Signal()
    editingCancelled = Signal()
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        self.current_tool = EditorTool.NODE
        self.current_point_type = PointType.SMOOTH
        
        # Widget setup
        self.setFixedHeight(38)  # Increased from 32 to account for border + padding + buttons
        self.setup_ui()
        self.setVisible(False)
        
        # Ensure widget stays on top and captures mouse events
        self.setAttribute(QtCore.Qt.WA_StyledBackground, True)
        self.setMouseTracking(True)
    
    def setup_ui(self):
        """Set up the UI layout and widgets."""
        layout = QtWidgets.QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        layout.addStretch()
        
        # Main frame
        self.frame = QtWidgets.QFrame()
        self.frame.setStyleSheet("""
            QFrame {
                background-color: rgba(40, 40, 40, 0.95);
                border: 1px solid rgba(80, 80, 80, 0.8);
                border-radius: 4px;
            }
        """)
        layout.addWidget(self.frame)
        
        frame_layout = QtWidgets.QHBoxLayout(self.frame)
        frame_layout.setContentsMargins(6, 6, 6, 6)
        frame_layout.setSpacing(6)
        
        # ============== Tool Buttons ==============
        self.tool_buttons = {}
        self.tool_group = QtWidgets.QButtonGroup(self)
        self.tool_group.setExclusive(True)
        
        tools = [
            (EditorTool.NODE, 'A', 'Node Tool (A) - Select and edit points', 'point-arrow-icon.png'),
            (EditorTool.PEN, 'P', 'Pen Tool (P) - Draw new paths', 'pen-tool-icon.png'),
            (EditorTool.RECTANGLE, 'R', 'Rectangle (R) - Draw rectangles', 'draw-rectangle-icon.png'),
            (EditorTool.ELLIPSE, 'O', 'Ellipse (O) - Draw ellipses', 'draw-elipses-icon.png'),
        ]
        
        for tool, shortcut, tooltip, icon_file in tools:
            btn = self._create_tool_button(shortcut, f"{tooltip}", icon_file=icon_file)
            btn.setCheckable(True)
            btn.setChecked(tool == self.current_tool)
            btn.clicked.connect(lambda checked, t=tool: self._on_tool_clicked(t))
            self.tool_group.addButton(btn)
            self.tool_buttons[tool] = btn
            frame_layout.addWidget(btn)
        
        # Separator
        frame_layout.addWidget(self._create_separator())
        
        # ============== Point Type Buttons ==============
        self.point_type_buttons = {}
        self.point_type_group = QtWidgets.QButtonGroup(self)
        self.point_type_group.setExclusive(True)
        
        point_types = [
            (PointType.CORNER, '⬜', 'Corner Point (Ctrl+Click) - Independent handles\nAlt+Click: Remove handles (sharp corner)\nCtrl+Shift+Click: Align linearly', 'independent-handle-icon.png'),
            (PointType.SMOOTH, '◯', 'Smooth Point (Shift+Click) - Colinear handles, curved', 'colinear-handle-icon.png'),
            (PointType.SYMMETRIC, '◉', 'Symmetric Point - Mirrored handles', 'mirrored-handle-icon.png'),
        ]

        for pt, symbol, tooltip, icon_file in point_types:
            btn = self._create_tool_button(symbol, tooltip, size=16, icon_file=icon_file)
            btn.setCheckable(True)
            btn.setChecked(pt == self.current_point_type)
            btn.clicked.connect(lambda checked, p=pt: self._on_point_type_clicked(p))
            self.point_type_group.addButton(btn)
            self.point_type_buttons[pt] = btn
            frame_layout.addWidget(btn)
        
        # Separator
        frame_layout.addWidget(self._create_separator())
        
        # ============== Action Buttons ==============
        # Done button
        self.done_btn = QtWidgets.QPushButton("✓")
        self.done_btn.setFixedSize(24, 24)
        self.done_btn.setToolTip("Apply Changes (Enter)")
        self.done_btn.setStyleSheet(self._get_action_button_style('#4CAF50'))
        self.done_btn.clicked.connect(self._on_done_clicked)
        frame_layout.addWidget(self.done_btn)
        
        # Cancel button
        self.cancel_btn = QtWidgets.QPushButton("✕")
        self.cancel_btn.setFixedSize(24, 24)
        self.cancel_btn.setToolTip("Cancel (Escape)")
        self.cancel_btn.setStyleSheet(self._get_action_button_style('#f44336'))
        self.cancel_btn.clicked.connect(self._on_cancel_clicked)
        frame_layout.addWidget(self.cancel_btn)
        
        layout.addStretch()
    
    def _create_tool_button(self, text: str, tooltip: str, size: int = 18, icon_file: str = None) -> QtWidgets.QPushButton:
        """Create a styled tool button."""
        btn = QtWidgets.QPushButton(text)
        btn.setFixedSize(24, 24)
        btn.setToolTip(tooltip)
        
        # Set icon if provided and utils is available
        if icon_file and HAS_UTILS:
            try:
                icon_pixmap = UT.get_icon(icon_file, size=16, opacity=0.9)
                btn.setIcon(QtGui.QIcon(icon_pixmap))
                btn.setText("")  # Clear text when icon is set
            except:
                pass  # Fall back to text if icon fails
        
        btn.setStyleSheet("""
            QPushButton {
                background-color: rgba(60, 60, 60, 0);
                border: 0px solid rgba(100, 100, 100, 150);
                border-radius: 3px;
                padding: 2px;
                color: #cccccc;
                font-size: 11px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: rgba(80, 80, 80, 220);
                border: 0px solid rgba(120, 120, 120, 180);
                color: #ffffff;
            }
            QPushButton:checked {
                background-color: rgba(75, 148, 234, 200);
                border: 0px solid rgba(100, 170, 255, 200);
                color: #ffffff;
            }
            QPushButton:pressed {
                background-color: rgba(50, 50, 50, 250);
            }
        """)
        return btn
    
    def _create_separator(self) -> QtWidgets.QFrame:
        """Create a vertical separator line."""
        sep = QtWidgets.QFrame()
        sep.setFrameShape(QtWidgets.QFrame.VLine)
        sep.setFixedWidth(1)
        sep.setStyleSheet("background-color: rgba(100, 100, 100, 100);")
        return sep
    
    def _get_action_button_style(self, color: str) -> str:
        """Get stylesheet for action buttons (Done/Cancel)."""
        return f"""
            QPushButton {{
                background-color: {color};
                color: white;
                border: none;
                border-radius: 3px;
                font-weight: bold;
                font-size: 13px;
            }}
            QPushButton:hover {{
                background-color: {color};
                border: 1px solid rgba(255, 255, 255, 0.3);
            }}
            QPushButton:pressed {{
                background-color: {color};
            }}
        """
    
    # ==================== Signal Handlers ====================
    
    def _on_tool_clicked(self, tool: EditorTool):
        """Handle tool button click."""
        self.current_tool = tool
        self.toolChanged.emit(tool)
    
    def _on_point_type_clicked(self, point_type: PointType):
        """Handle point type button click."""
        self.current_point_type = point_type
        self.pointTypeChanged.emit(point_type)
    
    def _on_done_clicked(self):
        """Handle done button click."""
        self.editingFinished.emit()
    
    def _on_cancel_clicked(self):
        """Handle cancel button click."""
        self.editingCancelled.emit()
    
    # ==================== External Control Methods ====================
    
    def set_tool(self, tool: EditorTool):
        """Programmatically set the active tool."""
        self.current_tool = tool
        if tool in self.tool_buttons:
            self.tool_buttons[tool].setChecked(True)
    
    def set_point_type(self, point_type: PointType):
        """Programmatically set the point type."""
        self.current_point_type = point_type
        if point_type in self.point_type_buttons:
            self.point_type_buttons[point_type].setChecked(True)
    
    def update_from_selection(self, selected_points):
        """
        Update point type display based on selected points.
        
        Args:
            selected_points: List of (path, point, path_idx, point_idx) tuples
        """
        if not selected_points:
            return
        
        # Get the point type of the first selected point
        _, point, _, _ = selected_points[0]
        self.set_point_type(point.point_type)
    
    def update_position(self, target_rect: QtCore.QRectF):
        """
        Update widget position to appear above the target rectangle.
        
        Args:
            target_rect: Rectangle to position above (in parent coordinates)
        """
        if not self.isVisible():
            return
        
        parent = self.parent()
        if not parent:
            return
        
        # Calculate position centered above target
        widget_width = self.sizeHint().width()
        new_x = target_rect.center().x() - widget_width / 2
        new_y = target_rect.top() - self.height() - 8  # 8px gap
        
        # Keep within parent bounds
        parent_rect = parent.rect()
        
        # If would go above parent, position below instead
        if new_y < 0:
            new_y = target_rect.bottom() + 8
        
        # Clamp horizontal position
        if new_x < 0:
            new_x = 0
        if new_x + widget_width > parent_rect.width():
            new_x = parent_rect.width() - widget_width
        
        self.move(int(new_x), int(new_y))
    
    def position_at_top(self, parent_width: int):
        """
        Position widget centered at top of parent.
        
        Args:
            parent_width: Width of parent widget
        """
        widget_width = self.sizeHint().width()
        new_x = (parent_width - widget_width) / 2
        self.move(int(new_x), 8)  # 8px from top
    
    # ==================== Event Handling ====================
    
    def showEvent(self, event):
        """Raise widget to top when shown."""
        super().showEvent(event)
        self.raise_()
    
    def mousePressEvent(self, event):
        """Accept mouse press to prevent it from passing through."""
        event.accept()
        super().mousePressEvent(event)
    
    def mouseMoveEvent(self, event):
        """Accept mouse move to prevent it from passing through."""
        event.accept()
        super().mouseMoveEvent(event)
    
    def mouseReleaseEvent(self, event):
        """Accept mouse release to prevent it from passing through."""
        event.accept()
        super().mouseReleaseEvent(event)
    
    # ==================== Fade Animation ====================
    
    def handle_enter_event(self):
        """Handle mouse entering widget - stop fade and show full opacity."""
        self.fade_timer.stop()
        self.fade_animation.stop()
        self.fade_animation.setDuration(100)
        self.fade_animation.setStartValue(self.opacity_effect.opacity())
        self.fade_animation.setEndValue(1.0)
        self.fade_animation.start()
    
    def handle_leave_event(self):
        """Handle mouse leaving widget - start fade timer."""
        self.fade_timer.start(800)  # Start fade after 800ms
    

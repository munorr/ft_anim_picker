"""
Selection Synchronization Manager for FT Anim Picker
Provides 2-way selection synchronization between Blender and the picker interface
"""

import bpy
from bpy.app.handlers import persistent
from PySide6 import QtCore
from PySide6.QtCore import QObject, Signal, QTimer
import weakref
from functools import wraps
import threading
from typing import Set, Dict, List, Optional, Tuple


class SelectionSyncManager(QObject):
    """
    Manages 2-way selection synchronization between FT Anim Picker and Blender.
    
    Features:
    - Listens to Blender selection changes via msgbus/handlers
    - Syncs picker button selections to Blender objects/bones
    - Syncs Blender selections back to picker buttons
    - Prevents infinite selection loops
    - Handles multiple picker instances
    """
    
    # Signals
    blender_selection_changed = Signal(list, list)  # objects, bones
    
    _instance = None
    _lock = threading.Lock()
    
    def __init__(self):
        super().__init__()
        
        # State management
        self._sync_enabled = True
        self._sync_lock = False  # Prevents infinite loops
        self._registered_canvases = weakref.WeakSet()
        
        # Blender state tracking
        self._last_selected_objects = set()
        self._last_selected_bones = set()
        self._last_active_object = None
        self._last_mode = None
        
        # Timer for debounced updates
        self._update_timer = QTimer()
        self._update_timer.setSingleShot(True)
        self._update_timer.timeout.connect(self._process_blender_selection_change)
        
        # msgbus subscription owner (for cleanup)
        self._msgbus_owner = object()
        
        # Button lookup optimization: maps (canvas, object_name) -> set of buttons
        self._button_lookup = {}  # {canvas: {obj_name: {buttons}, bone_key: {buttons}}}
        
        # Setup Blender monitoring
        self._setup_blender_handlers()
        
        print("SelectionSyncManager: Initialized 2-way selection synchronization with msgbus")
    
    @classmethod
    def get_instance(cls):
        """Get singleton instance of SelectionSyncManager"""
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = cls()
        return cls._instance
    
    @classmethod
    def cleanup_instance(cls):
        """Cleanup singleton instance"""
        if cls._instance:
            cls._instance.cleanup()
            cls._instance = None
    
    def register_canvas(self, canvas):
        """Register a picker canvas for selection synchronization"""
        self._registered_canvases.add(canvas)
        
        # Connect canvas signals
        if hasattr(canvas, 'button_selection_changed'):
            canvas.button_selection_changed.connect(self._on_picker_selection_changed)
        
        # Build lookup dictionary for this canvas
        self._build_button_lookup(canvas)
        
        print(f"SelectionSyncManager: Registered canvas {id(canvas)} with {len(canvas.buttons)} buttons")
    
    def unregister_canvas(self, canvas):
        """Unregister a picker canvas"""
        try:
            self._registered_canvases.discard(canvas)
            
            # Disconnect signals if still connected
            if hasattr(canvas, 'button_selection_changed'):
                try:
                    canvas.button_selection_changed.disconnect(self._on_picker_selection_changed)
                except:
                    pass  # Signal might not be connected
            
            # Remove lookup data for this canvas
            if canvas in self._button_lookup:
                del self._button_lookup[canvas]
                    
            print(f"SelectionSyncManager: Unregistered canvas {id(canvas)}")
        except Exception as e:
            print(f"SelectionSyncManager: Error unregistering canvas: {e}")
    
    def set_sync_enabled(self, enabled: bool):
        """Enable or disable synchronization"""
        self._sync_enabled = enabled
        print(f"SelectionSyncManager: Sync {'enabled' if enabled else 'disabled'}")
    
    def _setup_blender_handlers(self):
        """Setup msgbus subscriptions to monitor selection changes efficiently"""
        try:
            # Remove any existing handlers first
            self._cleanup_blender_handlers()
            
            # Subscribe to view layer active object changes
            try:
                subscribe_to = bpy.types.LayerObjects, "active"
                bpy.msgbus.subscribe_rna(
                    key=subscribe_to,
                    owner=self._msgbus_owner,
                    args=(),
                    notify=self._on_msgbus_selection_changed,
                    options={'PERSISTENT'}
                )
            except Exception as e:
                print(f"SelectionSyncManager: Could not subscribe to LayerObjects.active: {e}")
            
            # Subscribe to object selection changes via individual object properties
            # Note: Blender doesn't have a direct subscription for "all selected objects"
            # so we use depsgraph updates as a more reliable method
            try:
                # Subscribe to depsgraph updates which catch selection changes
                if self._depsgraph_handler not in bpy.app.handlers.depsgraph_update_post:
                    bpy.app.handlers.depsgraph_update_post.append(self._depsgraph_handler)
            except Exception as e:
                print(f"SelectionSyncManager: Could not add depsgraph handler: {e}")
            
            # Subscribe to context mode changes (for pose mode detection)
            try:
                # Monitor mode changes through window manager
                for window in bpy.context.window_manager.windows:
                    for area in window.screen.areas:
                        if area.type == 'VIEW_3D':
                            for space in area.spaces:
                                if space.type == 'VIEW_3D':
                                    subscribe_to = space.shading, "type"
                                    bpy.msgbus.subscribe_rna(
                                        key=subscribe_to,
                                        owner=self._msgbus_owner,
                                        args=(),
                                        notify=self._on_msgbus_mode_changed,
                                        options={'PERSISTENT'}
                                    )
                                    break
            except Exception as e:
                print(f"SelectionSyncManager: Could not subscribe to mode changes: {e}")
            
            # Add undo/redo handlers (still useful for these operations)
            if self._undo_handler not in bpy.app.handlers.undo_post:
                bpy.app.handlers.undo_post.append(self._undo_handler)
            if self._redo_handler not in bpy.app.handlers.redo_post:
                bpy.app.handlers.redo_post.append(self._redo_handler)
            
            # Add a lightweight frame change handler for pose mode bone selection
            if self._frame_change_handler not in bpy.app.handlers.frame_change_post:
                bpy.app.handlers.frame_change_post.append(self._frame_change_handler)
            
            print("SelectionSyncManager: msgbus subscriptions and handlers setup complete")
            
        except Exception as e:
            print(f"SelectionSyncManager: Error setting up Blender handlers: {e}")
    
    def _cleanup_blender_handlers(self):
        """Remove msgbus subscriptions and Blender handlers"""
        try:
            # Clear all msgbus subscriptions for this owner
            try:
                bpy.msgbus.clear_by_owner(self._msgbus_owner)
            except Exception as e:
                print(f"SelectionSyncManager: Error clearing msgbus subscriptions: {e}")
            
            # Remove handlers if they exist
            handlers_to_remove = [
                (bpy.app.handlers.undo_post, self._undo_handler),
                (bpy.app.handlers.redo_post, self._redo_handler),
                (bpy.app.handlers.frame_change_post, self._frame_change_handler),
                (bpy.app.handlers.depsgraph_update_post, self._depsgraph_handler),
            ]
            
            for handler_list, handler_func in handlers_to_remove:
                if handler_func in handler_list:
                    handler_list.remove(handler_func)
            
            print("SelectionSyncManager: msgbus subscriptions and handlers cleaned up")
            
        except Exception as e:
            print(f"SelectionSyncManager: Error cleaning up handlers: {e}")
    
    def _on_msgbus_selection_changed(self):
        """Callback for msgbus selection change events"""
        if not self._sync_enabled or self._sync_lock:
            return
        
        try:
            # Check if selection or mode changed
            current_objects = self._get_current_selected_objects()
            current_bones = self._get_current_selected_bones()
            current_active = bpy.context.view_layer.objects.active
            current_mode = bpy.context.mode
            
            selection_changed = (
                current_objects != self._last_selected_objects or
                current_bones != self._last_selected_bones or
                current_active != self._last_active_object or
                current_mode != self._last_mode
            )
            
            # Force update if everything is deselected (important for empty space clicks)
            if not current_objects and not current_bones and (self._last_selected_objects or self._last_selected_bones):
                selection_changed = True
            
            if selection_changed:
                # Debounce updates
                if not self._update_timer.isActive():
                    self._update_timer.start(50)  # 50ms delay
                
                # Update tracking
                self._last_selected_objects = current_objects
                self._last_selected_bones = current_bones
                self._last_active_object = current_active
                self._last_mode = current_mode
        
        except Exception as e:
            print(f"SelectionSyncManager: Error in msgbus selection handler: {e}")
    
    def _on_msgbus_mode_changed(self):
        """Callback for mode change events"""
        if not self._sync_enabled or self._sync_lock:
            return
        
        try:
            current_mode = bpy.context.mode
            if current_mode != self._last_mode:
                self._last_mode = current_mode
                if not self._update_timer.isActive():
                    self._update_timer.start(50)
        except Exception as e:
            print(f"SelectionSyncManager: Error in mode change handler: {e}")
    
    @persistent
    def _depsgraph_handler(self, scene, depsgraph):
        """Handle depsgraph updates to detect selection changes"""
        if not self._sync_enabled or self._sync_lock:
            return
        
        try:
            # Check if selection changed
            current_objects = self._get_current_selected_objects()
            current_bones = self._get_current_selected_bones()
            current_active = bpy.context.view_layer.objects.active
            current_mode = bpy.context.mode
            
            selection_changed = (
                current_objects != self._last_selected_objects or
                current_bones != self._last_selected_bones or
                current_active != self._last_active_object or
                current_mode != self._last_mode
            )
            
            # Force update if everything is deselected (important for empty space clicks)
            if not current_objects and not current_bones and (self._last_selected_objects or self._last_selected_bones):
                selection_changed = True
            
            if selection_changed:
                # Update tracking
                self._last_selected_objects = current_objects
                self._last_selected_bones = current_bones
                self._last_active_object = current_active
                self._last_mode = current_mode
                
                # Debounce updates
                if not self._update_timer.isActive():
                    self._update_timer.start(50)  # 50ms delay
        except Exception as e:
            pass  # Silent fail to avoid spam
    
    @persistent
    def _frame_change_handler(self, scene, depsgraph=None):
        """Lightweight handler for frame changes (mainly for pose mode bone selection)"""
        if not self._sync_enabled or self._sync_lock:
            return
        
        # Only check in pose mode (where bone selection matters)
        if bpy.context.mode != 'POSE':
            return
        
        try:
            current_bones = self._get_current_selected_bones()
            if current_bones != self._last_selected_bones:
                self._last_selected_bones = current_bones
                if not self._update_timer.isActive():
                    self._update_timer.start(50)
        except Exception as e:
            pass  # Silent fail for frame changes to avoid spam
    
    @persistent
    def _undo_handler(self, scene):
        """Handle undo operations"""
        if not self._sync_enabled:
            return
        self._trigger_selection_update()
    
    @persistent
    def _redo_handler(self, scene):
        """Handle redo operations"""
        if not self._sync_enabled:
            return
        self._trigger_selection_update()
    
    def _trigger_selection_update(self):
        """Trigger a selection update check"""
        if not self._update_timer.isActive():
            self._update_timer.start(100)  # 100ms delay for undo/redo
    
    def _get_current_selected_objects(self) -> Set[str]:
        """Get currently selected object names"""
        try:
            return {obj.name for obj in bpy.context.selected_objects}
        except:
            return set()
    
    def _get_current_selected_bones(self) -> Set[Tuple[str, str]]:
        """Get currently selected bone names with their armature"""
        try:
            bones = set()
            if bpy.context.mode == 'POSE':
                # Handle Blender version compatibility for selected pose bones
                selected_bones = getattr(bpy.context, 'selected_pose_bones_from_active_object', None)
                if not selected_bones:
                    selected_bones = getattr(bpy.context, 'selected_pose_bones', None)
                
                if selected_bones:
                    for bone in selected_bones:
                        armature_name = bone.id_data.name
                        bones.add((armature_name, bone.name))
            return bones
        except:
            return set()
    
    def _process_blender_selection_change(self):
        """Process Blender selection changes and sync to picker"""
        if not self._sync_enabled or self._sync_lock:
            return
        
        try:
            # Set sync lock to prevent infinite loops
            self._sync_lock = True
            
            # Get current selections
            selected_objects = list(self._last_selected_objects)
            selected_bones = [(armature, bone) for armature, bone in self._last_selected_bones]
            
            # Debug output for troubleshooting
            if not selected_objects and not selected_bones:
                print("SelectionSyncManager: Detected empty selection, syncing to picker")
            else:
                print(f"SelectionSyncManager: Syncing {len(selected_objects)} objects, {len(selected_bones)} bones to picker")
            
            # Emit signal for any listeners
            self.blender_selection_changed.emit(selected_objects, selected_bones)
            
            # Update picker canvases
            self._sync_blender_to_picker(selected_objects, selected_bones)
            
        except Exception as e:
            print(f"SelectionSyncManager: Error processing Blender selection change: {e}")
        finally:
            # Always release the lock with a small delay to ensure Blender state is stable
            from PySide6.QtCore import QTimer
            QTimer.singleShot(50, self._delayed_unlock)
    
    def _sync_blender_to_picker(self, selected_objects: List[str], selected_bones: List[Tuple[str, str]]):
        """Sync Blender selection to picker buttons - OPTIMIZED with lookup dictionary"""
        try:
            for canvas in list(self._registered_canvases):
                if canvas is None:
                    continue
                
                # Get lookup dictionary for this canvas
                lookup = self._button_lookup.get(canvas, {})
                if not lookup:
                    # Fallback to building lookup if it doesn't exist
                    self._build_button_lookup(canvas)
                    lookup = self._button_lookup.get(canvas, {})
                
                # Get current namespace for this canvas
                current_namespace = self._get_canvas_namespace(canvas)
                
                # Find buttons that should be selected using FAST LOOKUP
                buttons_to_select = set()
                
                # Check selected objects
                for obj_name in selected_objects:
                    obj_key = ('object', obj_name)
                    if obj_key in lookup:
                        buttons_to_select.update(lookup[obj_key])
                    
                    # Also check with namespace stripped (if namespace is active)
                    if current_namespace and current_namespace != 'None' and obj_name.startswith(f"{current_namespace}_"):
                        stripped_name = obj_name[len(current_namespace) + 1:]
                        stripped_key = ('object', stripped_name)
                        if stripped_key in lookup:
                            buttons_to_select.update(lookup[stripped_key])
                
                # Check selected bones
                for armature_name, bone_name in selected_bones:
                    bone_key = ('bone', armature_name, bone_name)
                    if bone_key in lookup:
                        buttons_to_select.update(lookup[bone_key])
                    
                    # Also check with namespace stripped (if namespace is active)
                    if current_namespace and current_namespace != 'None' and armature_name.startswith(f"{current_namespace}_"):
                        stripped_armature = armature_name[len(current_namespace) + 1:]
                        stripped_key = ('bone', stripped_armature, bone_name)
                        if stripped_key in lookup:
                            buttons_to_select.update(lookup[stripped_key])
                
                # Update button selection states
                self._update_canvas_selection(canvas, buttons_to_select)
        
        except Exception as e:
            print(f"SelectionSyncManager: Error syncing Blender to picker: {e}")
    
    def _get_canvas_namespace(self, canvas) -> Optional[str]:
        """Get the current namespace for a canvas"""
        try:
            # Try to get namespace from parent window
            main_window = canvas.window()
            if hasattr(main_window, '_get_current_namespace'):
                return main_window._get_current_namespace()
            elif hasattr(main_window, 'namespace_dropdown'):
                current_text = main_window.namespace_dropdown.currentText()
                return current_text if current_text != 'None' else None
        except:
            pass
        return None
    
    def _update_canvas_selection(self, canvas, buttons_to_select: Set):
        """Update canvas button selection states with batch optimization"""
        try:
            selection_changed = False
            
            # Batch all button updates together for better performance
            canvas.setUpdatesEnabled(False)
            
            for button in canvas.buttons:
                old_selected = button.is_selected
                new_selected = button in buttons_to_select
                
                if old_selected != new_selected:
                    button.is_selected = new_selected
                    # Don't call button.update() individually - batch it
                    selection_changed = True
            
            # Re-enable updates and do a single repaint
            canvas.setUpdatesEnabled(True)
            
            if selection_changed:
                # Single update for the entire canvas (much faster than per-button updates)
                canvas.update()
                # Emit canvas selection change signal
                canvas._emit_selection_changed()
        
        except Exception as e:
            print(f"SelectionSyncManager: Error updating canvas selection: {e}")
    
    def _delayed_unlock(self):
        """Release sync lock after a delay"""
        self._sync_lock = False
    
    def _build_button_lookup(self, canvas):
        """Build optimized lookup dictionary for fast button finding"""
        try:
            lookup = {}
            
            for button in canvas.buttons:
                if not hasattr(button, 'assigned_objects') or not button.assigned_objects:
                    continue
                
                for obj_data in button.assigned_objects:
                    if obj_data.get('is_bone', False):
                        # Create bone key: (armature_name, bone_name)
                        bone_name = obj_data.get('name', '')
                        armature_name = obj_data.get('armature', '')
                        bone_key = ('bone', armature_name, bone_name)
                        
                        if bone_key not in lookup:
                            lookup[bone_key] = set()
                        lookup[bone_key].add(button)
                    else:
                        # Create object key
                        obj_name = obj_data.get('name', '')
                        obj_key = ('object', obj_name)
                        
                        if obj_key not in lookup:
                            lookup[obj_key] = set()
                        lookup[obj_key].add(button)
            
            self._button_lookup[canvas] = lookup
            
        except Exception as e:
            print(f"SelectionSyncManager: Error building button lookup: {e}")
    
    def rebuild_button_lookup(self, canvas):
        """Rebuild lookup for a canvas (call when buttons are added/removed)"""
        self._build_button_lookup(canvas)
    
    def _on_picker_selection_changed(self):
        """Handle picker selection changes"""
        if not self._sync_enabled or self._sync_lock:
            return
        
        # The existing apply_final_selection in canvas already handles picker->Blender sync
        # We just need to make sure it doesn't conflict with our Blender->picker sync
        pass
    
    def cleanup(self):
        """Cleanup the sync manager"""
        try:
            self._sync_enabled = False
            self._cleanup_blender_handlers()
            
            # Clear registered canvases
            self._registered_canvases.clear()
            
            print("SelectionSyncManager: Cleanup complete")
        
        except Exception as e:
            print(f"SelectionSyncManager: Error during cleanup: {e}")


# Global functions for integration
def enable_selection_sync():
    """Enable 2-way selection synchronization"""
    manager = SelectionSyncManager.get_instance()
    manager.set_sync_enabled(True)


def disable_selection_sync():
    """Disable 2-way selection synchronization"""
    manager = SelectionSyncManager.get_instance()
    manager.set_sync_enabled(False)


def register_canvas_for_sync(canvas):
    """Register a canvas for selection synchronization"""
    manager = SelectionSyncManager.get_instance()
    manager.register_canvas(canvas)


def unregister_canvas_from_sync(canvas):
    """Unregister a canvas from selection synchronization"""
    manager = SelectionSyncManager.get_instance()
    manager.unregister_canvas(canvas)


def cleanup_selection_sync():
    """Cleanup selection synchronization"""
    SelectionSyncManager.cleanup_instance()


def rebuild_canvas_lookup(canvas):
    """
    Rebuild button lookup dictionary for a canvas.
    Call this when buttons are added/removed/modified to maintain performance.
    """
    manager = SelectionSyncManager.get_instance()
    manager.rebuild_button_lookup(canvas)

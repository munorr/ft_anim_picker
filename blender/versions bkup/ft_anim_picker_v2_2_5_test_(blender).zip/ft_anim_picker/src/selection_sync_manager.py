"""
Selection Synchronization Manager for FT Anim Picker
Provides 2-way selection synchronization between Blender and the picker interface
"""

import bpy
from bpy.app.handlers import persistent
from PySide6 import QtCore
from PySide6.QtCore import QObject, Signal, QTimer
import weakref
from functools import wraps
import threading
from typing import Set, Dict, List, Optional, Tuple


class SelectionSyncManager(QObject):
    """
    Manages 2-way selection synchronization between FT Anim Picker and Blender.
    
    Features:
    - Listens to Blender selection changes via msgbus/handlers
    - Syncs picker button selections to Blender objects/bones
    - Syncs Blender selections back to picker buttons
    - Prevents infinite selection loops
    - Handles multiple picker instances
    """
    
    # Signals
    blender_selection_changed = Signal(list, list)  # objects, bones
    
    _instance = None
    _lock = threading.Lock()
    
    def __init__(self):
        super().__init__()
        
        # State management
        self._sync_enabled = True
        self._sync_lock = False  # Prevents infinite loops
        self._registered_canvases = weakref.WeakSet()
        
        # Blender state tracking
        self._last_selected_objects = set()
        self._last_selected_bones = set()
        self._last_active_object = None
        self._last_mode = None
        
        # Timer for debounced updates
        self._update_timer = QTimer()
        self._update_timer.setSingleShot(True)
        self._update_timer.timeout.connect(self._process_blender_selection_change)
        
        # Setup Blender monitoring
        self._setup_blender_handlers()
        
        print("SelectionSyncManager: Initialized 2-way selection synchronization")
    
    @classmethod
    def get_instance(cls):
        """Get singleton instance of SelectionSyncManager"""
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = cls()
        return cls._instance
    
    @classmethod
    def cleanup_instance(cls):
        """Cleanup singleton instance"""
        if cls._instance:
            cls._instance.cleanup()
            cls._instance = None
    
    def register_canvas(self, canvas):
        """Register a picker canvas for selection synchronization"""
        self._registered_canvases.add(canvas)
        
        # Connect canvas signals
        if hasattr(canvas, 'button_selection_changed'):
            canvas.button_selection_changed.connect(self._on_picker_selection_changed)
        
        print(f"SelectionSyncManager: Registered canvas {id(canvas)}")
    
    def unregister_canvas(self, canvas):
        """Unregister a picker canvas"""
        try:
            self._registered_canvases.discard(canvas)
            
            # Disconnect signals if still connected
            if hasattr(canvas, 'button_selection_changed'):
                try:
                    canvas.button_selection_changed.disconnect(self._on_picker_selection_changed)
                except:
                    pass  # Signal might not be connected
                    
            print(f"SelectionSyncManager: Unregistered canvas {id(canvas)}")
        except Exception as e:
            print(f"SelectionSyncManager: Error unregistering canvas: {e}")
    
    def set_sync_enabled(self, enabled: bool):
        """Enable or disable synchronization"""
        self._sync_enabled = enabled
        print(f"SelectionSyncManager: Sync {'enabled' if enabled else 'disabled'}")
    
    def _setup_blender_handlers(self):
        """Setup Blender handlers to monitor selection changes"""
        try:
            # Remove any existing handlers first
            self._cleanup_blender_handlers()
            
            # Add scene update handler
            if self._scene_update_handler not in bpy.app.handlers.depsgraph_update_post:
                bpy.app.handlers.depsgraph_update_post.append(self._scene_update_handler)
            
            # Add undo/redo handlers
            if self._undo_handler not in bpy.app.handlers.undo_post:
                bpy.app.handlers.undo_post.append(self._undo_handler)
            if self._redo_handler not in bpy.app.handlers.redo_post:
                bpy.app.handlers.redo_post.append(self._redo_handler)
            
            print("SelectionSyncManager: Blender handlers setup complete")
            
        except Exception as e:
            print(f"SelectionSyncManager: Error setting up Blender handlers: {e}")
    
    def _cleanup_blender_handlers(self):
        """Remove Blender handlers"""
        try:
            # Remove handlers if they exist
            handlers_to_remove = [
                (bpy.app.handlers.depsgraph_update_post, self._scene_update_handler),
                (bpy.app.handlers.undo_post, self._undo_handler),
                (bpy.app.handlers.redo_post, self._redo_handler),
            ]
            
            for handler_list, handler_func in handlers_to_remove:
                if handler_func in handler_list:
                    handler_list.remove(handler_func)
            
            print("SelectionSyncManager: Blender handlers cleaned up")
            
        except Exception as e:
            print(f"SelectionSyncManager: Error cleaning up handlers: {e}")
    
    @persistent
    def _scene_update_handler(self, scene, depsgraph):
        """Handle scene updates from Blender"""
        if not self._sync_enabled or self._sync_lock:
            return
        
        try:
            # Check if selection or mode changed
            current_objects = self._get_current_selected_objects()
            current_bones = self._get_current_selected_bones()
            current_active = bpy.context.view_layer.objects.active
            current_mode = bpy.context.mode
            
            selection_changed = (
                current_objects != self._last_selected_objects or
                current_bones != self._last_selected_bones or
                current_active != self._last_active_object or
                current_mode != self._last_mode
            )
            
            # Force update if everything is deselected (important for empty space clicks)
            if not current_objects and not current_bones and (self._last_selected_objects or self._last_selected_bones):
                selection_changed = True
            
            if selection_changed:
                # Debounce updates
                if not self._update_timer.isActive():
                    self._update_timer.start(50)  # 50ms delay
                
                # Update tracking
                self._last_selected_objects = current_objects
                self._last_selected_bones = current_bones
                self._last_active_object = current_active
                self._last_mode = current_mode
        
        except Exception as e:
            print(f"SelectionSyncManager: Error in scene update handler: {e}")
    
    @persistent
    def _undo_handler(self, scene):
        """Handle undo operations"""
        if not self._sync_enabled:
            return
        self._trigger_selection_update()
    
    @persistent
    def _redo_handler(self, scene):
        """Handle redo operations"""
        if not self._sync_enabled:
            return
        self._trigger_selection_update()
    
    def _trigger_selection_update(self):
        """Trigger a selection update check"""
        if not self._update_timer.isActive():
            self._update_timer.start(100)  # 100ms delay for undo/redo
    
    def _get_current_selected_objects(self) -> Set[str]:
        """Get currently selected object names"""
        try:
            return {obj.name for obj in bpy.context.selected_objects}
        except:
            return set()
    
    def _get_current_selected_bones(self) -> Set[Tuple[str, str]]:
        """Get currently selected bone names with their armature"""
        try:
            bones = set()
            if bpy.context.mode == 'POSE':
                # Handle Blender version compatibility for selected pose bones
                selected_bones = getattr(bpy.context, 'selected_pose_bones_from_active_object', None)
                if not selected_bones:
                    selected_bones = getattr(bpy.context, 'selected_pose_bones', None)
                
                if selected_bones:
                    for bone in selected_bones:
                        armature_name = bone.id_data.name
                        bones.add((armature_name, bone.name))
            return bones
        except:
            return set()
    
    def _process_blender_selection_change(self):
        """Process Blender selection changes and sync to picker"""
        if not self._sync_enabled or self._sync_lock:
            return
        
        try:
            # Set sync lock to prevent infinite loops
            self._sync_lock = True
            
            # Get current selections
            selected_objects = list(self._last_selected_objects)
            selected_bones = [(armature, bone) for armature, bone in self._last_selected_bones]
            
            # Debug output for troubleshooting
            if not selected_objects and not selected_bones:
                print("SelectionSyncManager: Detected empty selection, syncing to picker")
            else:
                print(f"SelectionSyncManager: Syncing {len(selected_objects)} objects, {len(selected_bones)} bones to picker")
            
            # Emit signal for any listeners
            self.blender_selection_changed.emit(selected_objects, selected_bones)
            
            # Update picker canvases
            self._sync_blender_to_picker(selected_objects, selected_bones)
            
        except Exception as e:
            print(f"SelectionSyncManager: Error processing Blender selection change: {e}")
        finally:
            # Always release the lock with a small delay to ensure Blender state is stable
            from PySide6.QtCore import QTimer
            QTimer.singleShot(50, self._delayed_unlock)
    
    def _sync_blender_to_picker(self, selected_objects: List[str], selected_bones: List[Tuple[str, str]]):
        """Sync Blender selection to picker buttons"""
        try:
            for canvas in list(self._registered_canvases):
                if canvas is None:
                    continue
                
                # Get current namespace for this canvas
                current_namespace = self._get_canvas_namespace(canvas)
                
                # Find buttons that should be selected
                buttons_to_select = set()
                
                for button in canvas.buttons:
                    if not hasattr(button, 'assigned_objects') or not button.assigned_objects:
                        continue
                    
                    button_should_be_selected = False
                    
                    for obj_data in button.assigned_objects:
                        if obj_data.get('is_bone', False):
                            # Check bone selection
                            bone_name = obj_data.get('name', '')
                            armature_name = obj_data.get('armature', '')
                            
                            # Handle namespace
                            if current_namespace and current_namespace != 'None':
                                expected_armature = f"{current_namespace}_{armature_name}"
                            else:
                                expected_armature = armature_name
                            
                            if (expected_armature, bone_name) in selected_bones or (armature_name, bone_name) in selected_bones:
                                button_should_be_selected = True
                                break
                        else:
                            # Check object selection
                            obj_name = obj_data.get('name', '')
                            
                            # Handle namespace
                            if current_namespace and current_namespace != 'None':
                                expected_obj = f"{current_namespace}_{obj_name}"
                            else:
                                expected_obj = obj_name
                            
                            if expected_obj in selected_objects or obj_name in selected_objects:
                                button_should_be_selected = True
                                break
                    
                    if button_should_be_selected:
                        buttons_to_select.add(button)
                
                # Update button selection states
                self._update_canvas_selection(canvas, buttons_to_select)
        
        except Exception as e:
            print(f"SelectionSyncManager: Error syncing Blender to picker: {e}")
    
    def _get_canvas_namespace(self, canvas) -> Optional[str]:
        """Get the current namespace for a canvas"""
        try:
            # Try to get namespace from parent window
            main_window = canvas.window()
            if hasattr(main_window, '_get_current_namespace'):
                return main_window._get_current_namespace()
            elif hasattr(main_window, 'namespace_dropdown'):
                current_text = main_window.namespace_dropdown.currentText()
                return current_text if current_text != 'None' else None
        except:
            pass
        return None
    
    def _update_canvas_selection(self, canvas, buttons_to_select: Set):
        """Update canvas button selection states"""
        try:
            selection_changed = False
            
            for button in canvas.buttons:
                old_selected = button.is_selected
                new_selected = button in buttons_to_select
                
                if old_selected != new_selected:
                    button.is_selected = new_selected
                    button.update()
                    selection_changed = True
            
            if selection_changed:
                # Emit canvas selection change signal
                canvas._emit_selection_changed()
        
        except Exception as e:
            print(f"SelectionSyncManager: Error updating canvas selection: {e}")
    
    def _delayed_unlock(self):
        """Release sync lock after a delay"""
        self._sync_lock = False
    
    def _on_picker_selection_changed(self):
        """Handle picker selection changes"""
        if not self._sync_enabled or self._sync_lock:
            return
        
        # The existing apply_final_selection in canvas already handles picker->Blender sync
        # We just need to make sure it doesn't conflict with our Blender->picker sync
        pass
    
    def cleanup(self):
        """Cleanup the sync manager"""
        try:
            self._sync_enabled = False
            self._cleanup_blender_handlers()
            
            # Clear registered canvases
            self._registered_canvases.clear()
            
            print("SelectionSyncManager: Cleanup complete")
        
        except Exception as e:
            print(f"SelectionSyncManager: Error during cleanup: {e}")


# Global functions for integration
def enable_selection_sync():
    """Enable 2-way selection synchronization"""
    manager = SelectionSyncManager.get_instance()
    manager.set_sync_enabled(True)


def disable_selection_sync():
    """Disable 2-way selection synchronization"""
    manager = SelectionSyncManager.get_instance()
    manager.set_sync_enabled(False)


def register_canvas_for_sync(canvas):
    """Register a canvas for selection synchronization"""
    manager = SelectionSyncManager.get_instance()
    manager.register_canvas(canvas)


def unregister_canvas_from_sync(canvas):
    """Unregister a canvas from selection synchronization"""
    manager = SelectionSyncManager.get_instance()
    manager.unregister_canvas(canvas)


def cleanup_selection_sync():
    """Cleanup selection synchronization"""
    SelectionSyncManager.cleanup_instance()

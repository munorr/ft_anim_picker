# FT Anim Picker - 2-Way Selection Synchronization

## Overview

This implementation provides seamless 2-way selection synchronization between the FT Anim Picker and Blender, greatly improving the user experience and making selection more intuitive.

## Features

### ✅ Picker to Blender Sync
- When you select buttons in the picker, corresponding objects/bones are automatically selected in Blender
- Supports both object mode and pose mode selections
- Handles namespace prefixes for multiple character rigs
- Respects modifier keys (Shift for additive selection, Ctrl for counterpart selection)

### ✅ Blender to Picker Sync  
- When you select objects/bones in Blender, corresponding picker buttons are automatically highlighted
- Real-time monitoring of Blender selection changes via handlers
- Debounced updates to prevent performance issues
- Works with undo/redo operations

### ✅ Advanced Features
- **Loop Prevention**: Smart sync lock system prevents infinite selection loops
- **Namespace Support**: Automatically handles namespace prefixes (e.g., "Character_01_")
- **Multi-Canvas Support**: Works with multiple picker windows simultaneously
- **Performance Optimized**: Uses efficient handlers and debounced updates
- **UI Controls**: Right-click context menu to enable/disable sync

## Implementation Details

### Core Components

1. **SelectionSyncManager** (`selection_sync_manager.py`)
   - Singleton pattern for global sync management
   - Blender handler registration for monitoring selection changes
   - Canvas registration and management
   - Loop prevention via sync locks

2. **PickerCanvas Integration** (`picker_canvas.py`)
   - Automatic registration with sync manager on creation
   - Enhanced `apply_final_selection()` with sync lock integration
   - Context menu options for sync control
   - Proper cleanup on canvas destruction

3. **BlenderUI Integration** (`blender_ui.py`)
   - Sync manager cleanup on window close
   - Import of sync manager module

4. **Testing Utilities** (`selection_sync_test.py`)
   - Test functions for verifying sync functionality
   - Debug utilities and status checking
   - Accessible from context menu

### Technical Architecture

```
FT Anim Picker Buttons ←→ Selection Sync Manager ←→ Blender Objects/Bones
                                    ↓
                            Sync Lock Prevention
                                    ↓
                              Multiple Canvases
                                    ↓
                            Namespace Resolution
```

## Usage

### Automatic Operation
- Selection sync is **automatically enabled** when picker windows are created
- No user intervention required for basic functionality
- Works seamlessly with existing picker workflows

### Manual Controls
1. **Right-click** on picker canvas
2. Navigate to **"Selection Sync"** submenu
3. Options available:
   - Enable/Disable 2-Way Sync
   - Test Sync System

### Testing
- Use the context menu "Test Sync System" option
- Check Blender console for sync status messages
- Test by selecting objects in both Blender and picker

## API Reference

### Public Functions
```python
# Enable/disable sync globally
SSM.enable_selection_sync()
SSM.disable_selection_sync()

# Register/unregister canvases
SSM.register_canvas_for_sync(canvas)
SSM.unregister_canvas_from_sync(canvas)

# Testing utilities
from . import selection_sync_test as SST
SST.run_sync_tests()
SST.get_sync_status()
```

### Canvas Methods
```python
# On any picker canvas
canvas.enable_selection_sync()
canvas.disable_selection_sync()
canvas._test_selection_sync()
```

## Technical Notes

### Blender Handler Integration
- Uses `bpy.app.handlers.depsgraph_update_post` for real-time monitoring
- Includes undo/redo handlers for complete coverage
- Proper handler cleanup prevents memory leaks

### Performance Considerations
- Debounced updates (50ms delay) prevent excessive processing
- Efficient set operations for selection comparison
- Sync locks prevent recursive selection updates
- WeakSet for canvas registration prevents memory leaks

### Namespace Handling
- Automatically detects namespace from main window dropdown
- Handles both prefixed (`Namespace_ObjectName`) and non-prefixed objects
- Falls back gracefully when namespace detection fails

## Troubleshooting

### Common Issues

1. **Sync not working**: Check if sync is enabled via context menu
2. **Performance issues**: Verify debounce timing and handler registration
3. **Namespace issues**: Ensure namespace dropdown is set correctly
4. **Loop detection**: Check console for sync lock messages
5. **Empty space deselection**: Fixed issue where clicking empty space would break sync until next picker selection

### Recent Fixes

#### v1.0.1 - Empty Space Deselection Fix
- **Issue**: After clicking empty space in picker to deselect all, Blender→Picker sync would not work until making a selection via picker button
- **Root Cause**: Sync lock timing issues during deselection sequence and insufficient detection of empty selections
- **Solution**: 
  - Added `_clear_all_selections()` method with proper sync lock management
  - Enhanced selection change detection for empty selections
  - Improved timing with delayed sync lock release
  - Added specific test case for this scenario

### Debug Information
- Enable verbose output by running test functions
- Check Blender console for sync manager messages
- Use `get_sync_status()` to verify sync state

### Known Limitations
- Requires Blender 3.0+ for handler compatibility
- Performance scales with scene complexity
- Namespace detection depends on UI dropdown state

## Future Enhancements

### Potential Improvements
- [ ] Visual indicators for sync status in UI
- [ ] Per-canvas sync enable/disable
- [ ] Sync preferences in addon settings
- [ ] Custom namespace mapping rules
- [ ] Performance metrics and optimization

### Extension Points
- Additional handler types for other Blender events
- Custom sync rules and filters
- Integration with other picker tools
- Export/import of sync configurations

## Changelog

### v1.0.0 (Initial Implementation)
- ✅ Core 2-way selection synchronization
- ✅ Blender handler integration  
- ✅ Canvas registration system
- ✅ Namespace support
- ✅ Loop prevention
- ✅ UI controls and testing utilities
- ✅ Performance optimization
- ✅ Proper cleanup and memory management

---

**Note**: This implementation seamlessly integrates with the existing FT Anim Picker codebase without breaking existing functionality. All existing picker features continue to work as expected with the added benefit of 2-way selection synchronization.

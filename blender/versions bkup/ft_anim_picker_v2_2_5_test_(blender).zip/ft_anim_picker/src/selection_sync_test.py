"""
Test utility for 2-way selection synchronization
"""

import bpy
from . import selection_sync_manager as SSM


def test_blender_to_picker_sync():
    """Test that Blender selection changes are reflected in picker"""
    print("Testing Blender to Picker sync...")
    
    # Get the sync manager
    manager = SSM.SelectionSyncManager.get_instance()
    
    # Manually trigger selection change
    try:
        # Simulate object selection in Blender
        selected_objects = ["Cube", "Sphere"]  # Example objects
        selected_bones = [("Armature", "Bone.001")]  # Example bones
        
        manager._sync_blender_to_picker(selected_objects, selected_bones)
        print("Blender to Picker sync test completed")
        
    except Exception as e:
        print(f"Error in Blender to Picker sync test: {e}")


def test_picker_to_blender_sync():
    """Test that picker selection changes are applied to Blender"""
    print("Testing Picker to Blender sync...")
    
    try:
        # This relies on the existing apply_final_selection mechanism
        # which is already implemented in picker_canvas.py
        print("Picker to Blender sync relies on existing apply_final_selection mechanism")
        print("Test: Click on picker buttons to verify Blender selection updates")
        
    except Exception as e:
        print(f"Error in Picker to Blender sync test: {e}")


def enable_sync_debugging():
    """Enable verbose debugging for selection sync"""
    print("Enabling selection sync debugging...")
    
    # The sync manager already has print statements for debugging
    # This function could be extended to set more verbose logging
    manager = SSM.SelectionSyncManager.get_instance()
    manager.set_sync_enabled(True)
    print("Selection sync debugging enabled")


def disable_sync():
    """Disable selection synchronization"""
    print("Disabling selection sync...")
    SSM.disable_selection_sync()
    print("Selection sync disabled")


def enable_sync():
    """Enable selection synchronization"""
    print("Enabling selection sync...")
    SSM.enable_selection_sync()
    print("Selection sync enabled")


def get_sync_status():
    """Get current synchronization status"""
    try:
        manager = SSM.SelectionSyncManager.get_instance()
        status = "enabled" if manager._sync_enabled else "disabled"
        print(f"Selection sync is currently: {status}")
        print(f"Registered canvases: {len(manager._registered_canvases)}")
        return status
    except Exception as e:
        print(f"Error getting sync status: {e}")
        return "unknown"


# Convenience functions for use from within Blender
def test_empty_space_deselection():
    """Test that deselection via empty space click properly maintains sync"""
    print("Testing empty space deselection sync...")
    
    try:
        import bpy
        
        # First, select some objects in Blender
        bpy.ops.object.select_all(action='DESELECT')
        
        # Select a few objects if they exist
        test_objects = ['Cube', 'Sphere', 'Plane']
        selected_any = False
        
        for obj_name in test_objects:
            if obj_name in bpy.data.objects:
                bpy.data.objects[obj_name].select_set(True)
                selected_any = True
                print(f"Selected {obj_name} in Blender")
        
        if not selected_any:
            print("No test objects found, creating a cube...")
            bpy.ops.mesh.primitive_cube_add()
            bpy.context.active_object.select_set(True)
            selected_any = True
        
        if selected_any:
            print("Now click on empty space in the picker to test deselection sync")
            print("Then try selecting objects in Blender to verify sync is working")
        else:
            print("Could not set up test - no objects available")
    
    except Exception as e:
        print(f"Error in empty space deselection test: {e}")


def run_sync_tests():
    """Run all sync tests"""
    print("="*50)
    print("Running FT Anim Picker Selection Sync Tests")
    print("="*50)
    
    get_sync_status()
    test_blender_to_picker_sync()
    test_picker_to_blender_sync()
    test_empty_space_deselection()
    
    print("="*50)
    print("Test completed. Check console output above.")
    print("="*50)


def print_sync_info():
    """Print information about the selection sync system"""
    print("="*50)
    print("FT Anim Picker 2-Way Selection Sync System")
    print("="*50)
    print("Features:")
    print("- Automatic sync from picker buttons to Blender objects/bones")
    print("- Automatic sync from Blender selection to picker buttons")
    print("- Namespace support for multiple character rigs")
    print("- Prevention of infinite selection loops")
    print("- Support for both object and pose mode selections")
    print("")
    print("Usage:")
    print("- Selection sync is automatically enabled when picker windows are created")
    print("- Use enable_sync() and disable_sync() to control synchronization")
    print("- Use get_sync_status() to check current status")
    print("="*50)

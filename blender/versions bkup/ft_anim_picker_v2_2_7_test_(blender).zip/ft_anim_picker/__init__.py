bl_info = {
    "name": "FT Animation Picker",
    "author": "MUNORR - [Floating Tools]",
    "version": (2, 2, 7),
    "blender": (4, 0, 0),
    "location": "Main Menu > FT > Anim Picker",
    "description": "Animation picker for Blender",
    "category": "Animation",
}

import bpy
import sys
import os
from .src import utils as UT

# Make sure PySide6 is available
try:
    from PySide6 import QtWidgets
except ImportError:
    print("PySide6 not found. Please install it to use FT Animation Picker.")

# Add the src directory to the path
src_dir = os.path.join(os.path.dirname(__file__), "src")
if src_dir not in sys.path:
    sys.path.append(src_dir)

# Import the Blender-specific modules
from .src import blender_main

# Data is managed by the PickerDataManager class in src/data_management.py
# add SoP
class FT_AddonPreferences(bpy.types.AddonPreferences):
    bl_idname = __name__  # Must match the module name

    image_path: bpy.props.StringProperty(
        name="Image Folder",
        description="Base path for images used by this add-on",
        subtype='DIR_PATH',
        default="//"  # Blender’s relative path to .blend file
    )


    unhide_collection_when_sel: bpy.props.BoolProperty(
        name="unhide collection when Bone selected",
        description="Assure collection is visible when bone is selected",
        default=False
    )

    def draw(self, context):
        layout = self.layout
        layout.label(text="Image Path Settings")
        layout.prop(self, "image_path")

        layout.separator()

        layout.label(text="Behavior")
        layout.prop(self, "unhide_collection_when_sel")

        layout.separator()

        # Buttons section
        row = layout.row()
        row.operator(
            "wm.url_open",
            text="Original Addon by Munorr",
            icon="URL"
        ).url = "https://munorr.gumroad.com/l/ft-anim-picker-blender"

        row = layout.row()
        row.operator(
            "wm.url_open",
            text="Tweaked by SoulOfPuppet for LaChouette",
            icon="HEART"
        ).url = "https://www.soulofpuppet.com"


# FT Main Menu class
class FT_MT_main_menu(bpy.types.Menu):
    bl_idname = "FT_MT_main_menu"
    bl_label = "FT"
    
    def draw(self, context):
        layout = self.layout
        layout.operator(blender_main.ANIM_OT_open_ft_picker.bl_idname, text="Anim Picker")
        layout.operator("wm.url_open", text="Help").url = "https://munorr.com/tools/ft-anim-picker?tab=manual"

# Function to add the FT menu to the main menu bar
def add_ft_menu(self, context):
    self.layout.menu(FT_MT_main_menu.bl_idname)

# Register the addon
def register():
    # Register the main functionality
    blender_main.register()
    
    # Register the FT menu
    bpy.utils.register_class(FT_MT_main_menu)
    bpy.utils.register_class(FT_AddonPreferences)
    
    # Add the FT menu to the main menu bar (after the Help menu)
    bpy.types.TOPBAR_MT_editor_menus.append(add_ft_menu)

def unregister():
    # Remove the FT menu from the main menu bar
    bpy.types.TOPBAR_MT_editor_menus.remove(add_ft_menu)
    
    # Unregister the FT menu
    bpy.utils.unregister_class(FT_MT_main_menu)
    bpy.utils.unregister_class(FT_AddonPreferences)
    
    # Unregister the main functionality
    blender_main.unregister()

if __name__ == "__main__":
    register()

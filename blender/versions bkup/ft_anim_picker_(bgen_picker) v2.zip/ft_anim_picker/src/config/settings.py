"""
Application Configuration
Centralized configuration for application settings
"""

import os
from pathlib import Path

# ============================================================================
# Application Settings
# ============================================================================
APP_NAME = "BGEN Asset Library"
APP_VERSION = "3.0.0"

# Default download location
DEFAULT_DOWNLOAD_DIR = Path.home() / "Downloads" / "BGEN Assets"

# Picker Templates
TEMPLATE_DIR = Path(__file__).resolve().parent.parent / "picker_templates"

# BPicker Library
DEFAULT_LIBRARY_PATH = Path.home() / "Documents" / "BGEN_Picker" / "Library"
LEGACY_LIBRARY_PATH = Path.home() / "Documents" / "FT_Anim_Picker" / "Library"
BPICKER_EXTENSION = ".bpicker"
LIBRARY_INDEX_NAME = "library_index.json"
BPICKER_MANIFEST_VERSION = 1

# UI Settings
WINDOW_MIN_WIDTH = 300
WINDOW_MIN_HEIGHT = 300
ASSET_GRID_MAX_COLS = 5
CARD_SIZE = 84
THUMBNAIL_SIZE = CARD_SIZE - (CARD_SIZE * 0.1)
PAGE_SEGMENT_CONTROL_SIZE = 18

# Download settings
DOWNLOAD_CHUNK_SIZE = 8192  # bytes

# FONT SETTINGS
FONT_SIZE_SMALL = 12
FONT_SIZE_MEDIUM = 14
FONT_SIZE_LARGE = 16

# External URLs
GITHUB_URL = "https://github.com/munorr/ft_anim_picker"
GITHUB_ISSUES_URL = "https://github.com/munorr/ft_anim_picker/issues"
AUTHOR_NAME = "MUNORR - BGEN"

# ============================================================================
# Supabase Auth
# ============================================================================
SUPABASE_URL = "https://bdolptrvawlzfntyvjdl.supabase.co"          # Project URL, e.g. "https://xxxxx.supabase.co"
SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJkb2xwdHJ2YXdsemZudHl2amRsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzIzMTI3NzAsImV4cCI6MjA4Nzg4ODc3MH0.xaXES5cn7FxBLp9-fNBTOwsezsj3wCUdTgWz6TgBqYU"     # Public anon key (safe to embed — RLS protects data)
AUTH_PREFS_FILE = "auth_prefs.json"
TOKEN_REFRESH_MARGIN = 300  # Refresh 5 min before expiry (seconds)

# Google OAuth — Supabase redirect captures the token via fragment
GOOGLE_OAUTH_REDIRECT = f"{SUPABASE_URL}/auth/v1/callback"
OAUTH_LOCAL_PORT = 8457  # Localhost port for capturing OAuth callback tokens
OAUTH_POLL_INTERVAL = 2000  # ms between session polls after OAuth redirect
OAUTH_POLL_TIMEOUT = 120000  # ms total timeout for OAuth polling

# Session heartbeat — how often to update last_active_at on user_sessions
SESSION_HEARTBEAT_INTERVAL = 1800000  # 30 minutes in milliseconds

# ============================================================================
# Marketplace
# ============================================================================
MARKETPLACE_CARD_SIZE = CARD_SIZE  # Reuse standard card size

# Cache TTLs (seconds)
MARKETPLACE_CACHE_TTL = 300          # 5 min — products + sections
ENTITLEMENT_CACHE_TTL = 60           # 1 min — ownership checks
FEATURE_FLAG_CACHE_TTL = 3600        # 1 hour — feature flags
THUMBNAIL_CACHE_TTL = 86400          # 24 hours — thumbnail images

# Disk cache file names
MARKETPLACE_CACHE_FILE = "marketplace_cache.json"
MARKETPLACE_THUMBNAIL_DIR = "thumbnail_cache"

# Purchase polling
PURCHASE_POLL_INTERVAL = 3000        # 3s between ownership polls during checkout
PURCHASE_POLL_TIMEOUT = 120000       # 2 min max wait

# Storage bucket names
MARKETPLACE_THUMBNAILS_BUCKET = "marketplace-thumbnails"

# Feature flag keys (match marketplace_feature_flags table)
FF_MARKETPLACE_ENABLED = "marketplace_enabled"
FF_MARKETPLACE_MIN_VERSION = "marketplace_min_version"
FF_MARKETPLACE_REQUIRE_AUTH = "marketplace_require_auth"  # Purchase gating (handled in code)
FF_MARKETPLACE_BROWSE_AUTH = "marketplace_browse_auth"    # Browse gating (blocks non-signed-in users)


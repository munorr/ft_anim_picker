"""BGEN Picker - A powerful animation picker tool for Maya and Blender

Part of the BGEN collection.
"""

__version__ = '3.0.0'
__author__ = 'MUNORR - BGEN'

# Note: Import functions only when explicitly needed to avoid circular imports
# from .blender_main import open  # Available but not auto-imported

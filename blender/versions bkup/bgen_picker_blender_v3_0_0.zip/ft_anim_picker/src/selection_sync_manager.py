"""
Selection Synchronization Manager for BGEN Picker
Provides 2-way selection synchronization between Blender and the picker interface.

Architecture (dual-timer bridge for macOS compatibility):
  - bpy.app.timers callback:  reads Blender selection state, stores in shared vars
  - QTimer callback:           reads shared vars, updates Qt/picker widgets

Neither timer crosses the Blender<->Qt event-loop boundary, which is
essential on macOS where the two run loops are separate.
"""

import bpy
from PySide6 import QtCore
from PySide6.QtCore import QObject, Signal, QTimer
import weakref
import warnings
import threading
from typing import Set, List, Optional, Tuple


class SelectionSyncManager(QObject):
    """
    Manages 2-way selection synchronization between BGEN Picker and Blender.
    """

    # Signals
    blender_selection_changed = Signal(list, list)  # objects, bones

    _instance = None
    _lock = threading.Lock()

    def __init__(self):
        super().__init__()

        # State management
        self._sync_enabled = True
        self._sync_lock = False
        self._registered_canvases = weakref.WeakSet()
        self._canvas_strong_refs = []

        # --- Shared data between the two timers ---
        # Written by Blender timer, read by Qt timer
        self._pending_change = False
        self._pending_objects = []       # list of object name strings
        self._pending_bones = []         # list of (armature_name, bone_name) tuples

        # Blender-side cached state (only touched by Blender timer)
        self._last_selected_objects = set()
        self._last_selected_bones = set()
        self._last_active_object_name = None
        self._last_mode = None

        # Flag set by depsgraph handler
        self._check_requested = False

        # Button lookup optimization
        self._button_lookup = {}

        # --- Qt timer: syncs shared data to picker widgets ---
        # Created here (Qt context) so it fires reliably on all platforms
        self._qt_sync_timer = QTimer()
        self._qt_sync_timer.timeout.connect(self._qt_sync_callback)
        self._qt_sync_timer.start(100)  # 100ms

        # --- Blender timer: reads selection state ---
        self._blender_timer_registered = False
        self._register_blender_timer()

        # Depsgraph handler (supplementary)
        self._setup_depsgraph_handler()

        print("SelectionSyncManager: Initialized (dual-timer bridge)")

    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = cls()
        return cls._instance

    @classmethod
    def cleanup_instance(cls):
        if cls._instance:
            cls._instance.cleanup()
            cls._instance = None

    # ------------------------------------------------------------------
    # Canvas registration
    # ------------------------------------------------------------------

    def register_canvas(self, canvas):
        self._registered_canvases.add(canvas)
        if canvas not in self._canvas_strong_refs:
            self._canvas_strong_refs.append(canvas)

        if hasattr(canvas, 'button_selection_changed'):
            canvas.button_selection_changed.connect(self._on_picker_selection_changed)

        self._build_button_lookup(canvas)
        print(f"SelectionSyncManager: Registered canvas with {len(canvas.buttons)} buttons")

    def unregister_canvas(self, canvas):
        try:
            self._registered_canvases.discard(canvas)
            if canvas in self._canvas_strong_refs:
                self._canvas_strong_refs.remove(canvas)
            if hasattr(canvas, 'button_selection_changed'):
                try:
                    canvas.button_selection_changed.disconnect(self._on_picker_selection_changed)
                except Exception:
                    pass
            if canvas in self._button_lookup:
                del self._button_lookup[canvas]
        except Exception as e:
            print(f"SelectionSyncManager: Error unregistering canvas: {e}")

    def set_sync_enabled(self, enabled: bool):
        self._sync_enabled = enabled
        if enabled:
            self._register_blender_timer()
            if not self._qt_sync_timer.isActive():
                self._qt_sync_timer.start(100)
        else:
            self._qt_sync_timer.stop()
        print(f"SelectionSyncManager: Sync {'enabled' if enabled else 'disabled'}")

    # ------------------------------------------------------------------
    # BLENDER TIMER — reads bpy.context, writes shared vars
    # Does NOT touch any Qt objects.
    # ------------------------------------------------------------------

    def _register_blender_timer(self):
        if self._blender_timer_registered:
            return
        try:
            bpy.app.timers.register(
                self._blender_timer_callback,
                first_interval=0.2,
                persistent=True
            )
            self._blender_timer_registered = True
        except Exception as e:
            print(f"SelectionSyncManager: Error registering Blender timer: {e}")

    def _blender_timer_callback(self):
        """Runs in Blender's event loop. Reads selection, stores in shared vars."""
        if not self._sync_enabled:
            return 0.5
        if self._sync_lock:
            return 0.1
        if not self._canvas_strong_refs:
            return 0.5

        try:
            changed = self._detect_selection_change()
            if changed:
                # Write to shared vars (Qt timer will pick these up)
                self._pending_objects = list(self._last_selected_objects)
                self._pending_bones = list(self._last_selected_bones)
                self._pending_change = True
        except Exception as e:
            print(f"SelectionSyncManager: Blender timer error: {e}")

        if self._check_requested:
            self._check_requested = False
            return 0.05
        return 0.15

    def _detect_selection_change(self) -> bool:
        """Read current Blender selection. Only called from Blender timer."""
        try:
            current_objects = set()
            current_bones = set()
            current_active_name = None
            current_mode = None

            try:
                current_mode = bpy.context.mode
            except Exception:
                return False

            try:
                for obj in bpy.context.selected_objects:
                    current_objects.add(obj.name)
            except Exception:
                pass

            try:
                active = bpy.context.view_layer.objects.active
                current_active_name = active.name if active else None
            except Exception:
                pass

            if current_mode == 'POSE':
                try:
                    selected = getattr(bpy.context, 'selected_pose_bones_from_active_object', None)
                    if not selected:
                        selected = getattr(bpy.context, 'selected_pose_bones', None)
                    if selected:
                        for bone in selected:
                            current_bones.add((bone.id_data.name, bone.name))
                except Exception:
                    pass

            changed = (
                current_objects != self._last_selected_objects
                or current_bones != self._last_selected_bones
                or current_active_name != self._last_active_object_name
                or current_mode != self._last_mode
            )

            if (not current_objects and not current_bones
                    and (self._last_selected_objects or self._last_selected_bones)):
                changed = True

            if changed:
                self._last_selected_objects = current_objects
                self._last_selected_bones = current_bones
                self._last_active_object_name = current_active_name
                self._last_mode = current_mode

            return changed
        except Exception:
            return False

    # ------------------------------------------------------------------
    # DEPSGRAPH HANDLER — just sets a flag, no context reading
    # ------------------------------------------------------------------

    def _setup_depsgraph_handler(self):
        try:
            self._cleanup_depsgraph_handler()
            _self_ref = weakref.ref(self)

            def _on_depsgraph_update(scene, depsgraph):
                s = _self_ref()
                if s is not None and s._sync_enabled and not s._sync_lock:
                    s._check_requested = True

            _on_depsgraph_update._bpy_persistent = True
            self._depsgraph_fn = _on_depsgraph_update
            bpy.app.handlers.depsgraph_update_post.append(self._depsgraph_fn)
        except Exception as e:
            print(f"SelectionSyncManager: depsgraph handler error: {e}")

    def _cleanup_depsgraph_handler(self):
        try:
            fn = getattr(self, '_depsgraph_fn', None)
            if fn is not None:
                try:
                    bpy.app.handlers.depsgraph_update_post.remove(fn)
                except ValueError:
                    pass
        except Exception:
            pass

    # ------------------------------------------------------------------
    # QT TIMER — reads shared vars, updates picker widgets
    # Does NOT access bpy.context.
    # ------------------------------------------------------------------

    def _qt_sync_callback(self):
        """Runs in Qt's event loop. Reads shared vars, syncs to picker."""
        if not self._sync_enabled or self._sync_lock:
            return
        if not self._pending_change:
            return

        # Grab the pending data and clear the flag
        self._pending_change = False
        selected_objects = self._pending_objects
        selected_bones = self._pending_bones

        try:
            self._sync_lock = True

            # Emit signal
            self.blender_selection_changed.emit(selected_objects, selected_bones)

            # Sync to picker canvases (Qt widget updates)
            self._sync_blender_to_picker(selected_objects, selected_bones)

        except Exception as e:
            print(f"SelectionSyncManager: Qt sync error: {e}")
        finally:
            # Unlock after a short delay (QTimer works here — we're in Qt context)
            QTimer.singleShot(100, self._delayed_unlock)

    # ------------------------------------------------------------------
    # Sync logic: Blender -> Picker
    # ------------------------------------------------------------------

    def _sync_blender_to_picker(self, selected_objects: List[str],
                                 selected_bones: List[Tuple[str, str]]):
        """Update picker buttons to match Blender selection."""
        try:
            for canvas in list(self._registered_canvases):
                if canvas is None:
                    continue

                current_namespace = self._get_canvas_namespace(canvas)
                buttons_to_select = set()

                # --- Fast path: lookup dictionary ---
                lookup = self._button_lookup.get(canvas)
                if not lookup:
                    self._build_button_lookup(canvas)
                    lookup = self._button_lookup.get(canvas, {})

                for obj_name in selected_objects:
                    key = ('object', obj_name)
                    if key in lookup:
                        buttons_to_select.update(lookup[key])
                    if current_namespace and current_namespace != 'None':
                        if obj_name.startswith(f"{current_namespace}_"):
                            stripped = obj_name[len(current_namespace) + 1:]
                            skey = ('object', stripped)
                            if skey in lookup:
                                buttons_to_select.update(lookup[skey])

                for armature_name, bone_name in selected_bones:
                    key = ('bone', armature_name, bone_name)
                    if key in lookup:
                        buttons_to_select.update(lookup[key])
                    if current_namespace and current_namespace != 'None':
                        ns_key = ('bone', current_namespace, bone_name)
                        if ns_key in lookup:
                            buttons_to_select.update(lookup[ns_key])
                        if armature_name.startswith(f"{current_namespace}_"):
                            stripped_arm = armature_name[len(current_namespace) + 1:]
                            skey = ('bone', stripped_arm, bone_name)
                            if skey in lookup:
                                buttons_to_select.update(lookup[skey])

                # --- Fallback: brute-force match ---
                if not buttons_to_select and (selected_objects or selected_bones):
                    buttons_to_select = self._brute_force_match(
                        canvas, selected_objects, selected_bones, current_namespace
                    )

                self._update_canvas_selection(canvas, buttons_to_select)

        except Exception as e:
            print(f"SelectionSyncManager: Error syncing to picker: {e}")

    def _brute_force_match(self, canvas, selected_objects, selected_bones,
                           current_namespace) -> set:
        """Iterate all buttons with flexible name matching."""
        buttons_to_select = set()
        selected_bone_names = {bn for _, bn in selected_bones}
        selected_obj_set = set(selected_objects)

        for button in canvas.buttons:
            if not hasattr(button, 'assigned_objects') or not button.assigned_objects:
                continue
            should_select = False
            for obj_data in button.assigned_objects:
                if obj_data.get('is_bone', False):
                    bone_name = obj_data.get('name', '')
                    armature = obj_data.get('armature', '')
                    if not bone_name or bone_name not in selected_bone_names:
                        continue
                    for sel_arm, sel_bone in selected_bones:
                        if sel_bone != bone_name:
                            continue
                        if sel_arm == armature:
                            should_select = True; break
                        if current_namespace and armature == current_namespace:
                            should_select = True; break
                        if current_namespace and sel_arm.startswith(f"{current_namespace}_"):
                            if sel_arm[len(current_namespace) + 1:] == armature:
                                should_select = True; break
                        if not armature:
                            should_select = True; break
                    if should_select:
                        break
                else:
                    obj_name = obj_data.get('name', '')
                    if not obj_name:
                        continue
                    if obj_name in selected_obj_set:
                        should_select = True; break
                    if current_namespace and current_namespace != 'None':
                        if f"{current_namespace}_{obj_name}" in selected_obj_set:
                            should_select = True; break
                    for sel_obj in selected_objects:
                        if sel_obj.endswith(f"_{obj_name}"):
                            should_select = True; break
                    if should_select:
                        break
            if should_select:
                buttons_to_select.add(button)
        return buttons_to_select

    def _get_canvas_namespace(self, canvas) -> Optional[str]:
        try:
            main_window = canvas.window()
            if hasattr(main_window, '_get_current_namespace'):
                return main_window._get_current_namespace()
            elif hasattr(main_window, 'namespace_dropdown'):
                text = main_window.namespace_dropdown.currentText()
                return text if text != 'None' else None
        except Exception:
            pass
        return None

    def _update_canvas_selection(self, canvas, buttons_to_select: Set):
        try:
            selection_changed = False
            try:
                canvas.setUpdatesEnabled(False)
                for button in canvas.buttons:
                    old = button.is_selected
                    new = button in buttons_to_select
                    if old != new:
                        button.is_selected = new
                        selection_changed = True
            finally:
                canvas.setUpdatesEnabled(True)
            if selection_changed:
                canvas.update()
                canvas._emit_selection_changed()
        except Exception as e:
            print(f"SelectionSyncManager: Error updating canvas: {e}")

    def _delayed_unlock(self):
        self._sync_lock = False

    # ------------------------------------------------------------------
    # Button lookup
    # ------------------------------------------------------------------

    def _build_button_lookup(self, canvas):
        try:
            lookup = {}
            for button in canvas.buttons:
                if not hasattr(button, 'assigned_objects') or not button.assigned_objects:
                    continue
                for obj_data in button.assigned_objects:
                    if obj_data.get('is_bone', False):
                        bone_name = obj_data.get('name', '')
                        armature_name = obj_data.get('armature', '')
                        lookup.setdefault(('bone', armature_name, bone_name), set()).add(button)
                    else:
                        obj_name = obj_data.get('name', '')
                        lookup.setdefault(('object', obj_name), set()).add(button)
            self._button_lookup[canvas] = lookup
        except Exception as e:
            print(f"SelectionSyncManager: Error building lookup: {e}")

    def rebuild_button_lookup(self, canvas):
        self._build_button_lookup(canvas)

    def _on_picker_selection_changed(self):
        pass

    # ------------------------------------------------------------------
    # Cleanup
    # ------------------------------------------------------------------

    def cleanup(self):
        try:
            self._sync_enabled = False
            if self._qt_sync_timer.isActive():
                self._qt_sync_timer.stop()
            if self._blender_timer_registered:
                try:
                    bpy.app.timers.unregister(self._blender_timer_callback)
                except Exception:
                    pass
                self._blender_timer_registered = False
            self._cleanup_depsgraph_handler()
            self._registered_canvases.clear()
            self._canvas_strong_refs.clear()
            self._button_lookup.clear()
            print("SelectionSyncManager: Cleanup complete")
        except Exception as e:
            print(f"SelectionSyncManager: Error during cleanup: {e}")


# ------------------------------------------------------------------
# Global functions
# ------------------------------------------------------------------

def enable_selection_sync():
    manager = SelectionSyncManager.get_instance()
    manager.set_sync_enabled(True)

def disable_selection_sync():
    manager = SelectionSyncManager.get_instance()
    manager.set_sync_enabled(False)

def register_canvas_for_sync(canvas):
    manager = SelectionSyncManager.get_instance()
    manager.register_canvas(canvas)

def unregister_canvas_from_sync(canvas):
    manager = SelectionSyncManager.get_instance()
    manager.unregister_canvas(canvas)

def cleanup_selection_sync():
    SelectionSyncManager.cleanup_instance()

def rebuild_canvas_lookup(canvas):
    manager = SelectionSyncManager.get_instance()
    manager.rebuild_button_lookup(canvas)

def reconnect_canvas(canvas):
    manager = SelectionSyncManager.get_instance()
    if canvas not in manager._registered_canvases:
        return
    if hasattr(canvas, 'button_selection_changed'):
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", RuntimeWarning)
            try:
                canvas.button_selection_changed.disconnect(
                    manager._on_picker_selection_changed
                )
            except (RuntimeError, TypeError):
                pass
        canvas.button_selection_changed.connect(
            manager._on_picker_selection_changed
        )
